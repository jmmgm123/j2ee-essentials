/**
 * ScoreService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.mcnz.restful.java.example;

public interface ScoreService extends java.rmi.Remote {
    public java.lang.String update(int in0, int in1, int in2) throws java.rmi.RemoteException;
    public int increaseLosses() throws java.rmi.RemoteException;
    public int getWins() throws java.rmi.RemoteException;
    public int increaseTies() throws java.rmi.RemoteException;
    public int increaseWins() throws java.rmi.RemoteException;
    public int getLosses() throws java.rmi.RemoteException;
    public int getTies() throws java.rmi.RemoteException;
    public java.lang.String getScore() throws java.rmi.RemoteException;
}
