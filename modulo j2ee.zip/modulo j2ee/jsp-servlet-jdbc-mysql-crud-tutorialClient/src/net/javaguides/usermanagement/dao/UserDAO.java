/**
 * UserDAO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.javaguides.usermanagement.dao;

public interface UserDAO extends java.rmi.Remote {
    public net.javaguides.usermanagement.model.User selectUser(int id) throws java.rmi.RemoteException;
    public java.lang.Object[] selectAllUsers() throws java.rmi.RemoteException;
    public void insertUser(net.javaguides.usermanagement.model.User user) throws java.rmi.RemoteException;
    public boolean deleteUser(int id) throws java.rmi.RemoteException;
    public boolean updateUser(net.javaguides.usermanagement.model.User user) throws java.rmi.RemoteException;
}
