package net.javaguides.usermanagement.dao;

public class UserDAOProxy implements net.javaguides.usermanagement.dao.UserDAO {
  private String _endpoint = null;
  private net.javaguides.usermanagement.dao.UserDAO userDAO = null;
  
  public UserDAOProxy() {
    _initUserDAOProxy();
  }
  
  public UserDAOProxy(String endpoint) {
    _endpoint = endpoint;
    _initUserDAOProxy();
  }
  
  private void _initUserDAOProxy() {
    try {
      userDAO = (new net.javaguides.usermanagement.dao.UserDAOServiceLocator()).getUserDAO();
      if (userDAO != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)userDAO)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)userDAO)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (userDAO != null)
      ((javax.xml.rpc.Stub)userDAO)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public net.javaguides.usermanagement.dao.UserDAO getUserDAO() {
    if (userDAO == null)
      _initUserDAOProxy();
    return userDAO;
  }
  
  public net.javaguides.usermanagement.model.User selectUser(int id) throws java.rmi.RemoteException{
    if (userDAO == null)
      _initUserDAOProxy();
    return userDAO.selectUser(id);
  }
  
  public java.lang.Object[] selectAllUsers() throws java.rmi.RemoteException{
    if (userDAO == null)
      _initUserDAOProxy();
    return userDAO.selectAllUsers();
  }
  
  public void insertUser(net.javaguides.usermanagement.model.User user) throws java.rmi.RemoteException{
    if (userDAO == null)
      _initUserDAOProxy();
    userDAO.insertUser(user);
  }
  
  public boolean deleteUser(int id) throws java.rmi.RemoteException{
    if (userDAO == null)
      _initUserDAOProxy();
    return userDAO.deleteUser(id);
  }
  
  public boolean updateUser(net.javaguides.usermanagement.model.User user) throws java.rmi.RemoteException{
    if (userDAO == null)
      _initUserDAOProxy();
    return userDAO.updateUser(user);
  }
  
  
}