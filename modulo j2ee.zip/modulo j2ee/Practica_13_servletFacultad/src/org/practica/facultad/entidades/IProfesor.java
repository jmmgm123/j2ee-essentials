package org.practica.facultad.entidades;

public interface IProfesor extends IPersona, IEmpleado, IDepartamento {

	public int getIdProfesor();
	public void setIdProfesor(int id);
	public String aurl();

}
