package org.practica.facultad.entidades;

public interface IDepartamento {

	public String getNombreDep();

	public void setNombreDep(String nombreDep);
}
