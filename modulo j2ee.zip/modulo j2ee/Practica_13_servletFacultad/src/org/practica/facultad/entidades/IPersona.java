package org.practica.facultad.entidades;

public interface IPersona {
	
	public String getNombre();

	public void setNombre(String nombre);

	public String getApellido1();

	public void setApellido1(String apellido1);

	public String getApellido2(); 

	public void setApellido2(String apellido2);
	
	public String getDni();

	public void setDni(String dni);

	public String getEstadoCivil();

	public void setEstadoCivil(String estadoCivil);

}
