package org.practica.facultad.entidades;

public class Curso implements ICurso {

	private String nombreCurso;

	
	public Curso() {
	}
	
	/**
	 * @param nombreCurso
	 */
	public Curso(String nombreCurso) {
		this.nombreCurso = nombreCurso;
	}

	public String getNombreCurso() {
		return nombreCurso;
	}

	public void setNombreCurso(String nombreCurso) {
		this.nombreCurso = nombreCurso;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Curso other = (Curso) obj;
		if (nombreCurso == null) {
			if (other.nombreCurso != null)
				return false;
		} else if (!nombreCurso.equals(other.nombreCurso))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Curso [nombreCurso=" + nombreCurso + "]";
	}
	
	
	
	
}
