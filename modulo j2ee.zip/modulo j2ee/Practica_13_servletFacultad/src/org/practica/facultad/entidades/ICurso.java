package org.practica.facultad.entidades;

public interface ICurso {

	public String getNombreCurso();

	public void setNombreCurso(String nombreSec);
	
}
