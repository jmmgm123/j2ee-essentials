package org.practica.facultad.entidades;

public class Estudiante implements IPersona, ICurso  {

	private Persona pers;
	private Curso curso;
	
	
	public Estudiante() {
	}
	
	/**
	 * @param pers - Persona
	 * @param curso - Curso
	 */
	public Estudiante(Persona pers, Curso curso) {
		this.pers = pers;
		this.curso = curso;
	}

	//Persona
	
	@Override
	public String getNombre() {
		return pers.getNombre();
	}

	@Override
	public void setNombre(String nombre) {
		pers.setNombre(nombre);
	}

	@Override
	public String getApellido1() {
		return pers.getApellido1();
	}

	@Override
	public void setApellido1(String apellido1) {
		pers.setApellido1(apellido1);
		
	}

	@Override
	public String getApellido2() {
		return pers.getApellido2();
	}

	@Override
	public void setApellido2(String apellido2) {
		pers.setApellido2(apellido2);
		
	}

	@Override
	public String getDni() {
		return pers.getDni(); 
	}

	@Override
	public void setDni(String dni) {
		pers.setDni(dni);
		
	}

	@Override
	public String getEstadoCivil() {
		return pers.getEstadoCivil();
	}

	@Override
	public void setEstadoCivil(String estadoCivil) {
		pers.setEstadoCivil(estadoCivil);
		
	}

	//fin Persona

	//Curso
	
	@Override
	public String getNombreCurso() {
		return curso.getNombreCurso();
	}

	@Override
	public void setNombreCurso(String nombreCurso) {
		curso.setNombreCurso(nombreCurso);
		
	}


	//Fin Curso

	@Override
	public String toString() {
		return "Estudiante [pers=" + pers.toString() + ", curso=" + curso.toString() + "]";
	}


}
