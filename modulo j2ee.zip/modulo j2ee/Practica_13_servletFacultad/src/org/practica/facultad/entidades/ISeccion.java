package org.practica.facultad.entidades;

public interface ISeccion {
	
	public String getNombreSec();

	public void setNombreSec(String nombreSec);

}
