package org.practica.facultad.gestion;
import java.util.List;

import org.practica.facultad.entidades.IProfesor;

public class ControllerProfesor {
	
	public ControllerProfesor() {
	}
	
	//llama al DAO para guardar un cliente
	public boolean registrar(IProfesor profesor ) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.registrar(profesor);
	}
	
	public List<IProfesor> obtener(){
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.obtener();
	}
	
	public IProfesor obtenerId(String id){
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.obtenerId(id);
	}
	
	public void listarResultados(List<IProfesor> ListProf) {
		IProfesorDAO dao= new ProfesorDaoImp();
		dao.listarResultados(ListProf);
	}
	
	public boolean actualizar(IProfesor prof) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.actualizar(prof);
	}
	
	public boolean eliminar(IProfesor prof) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.eliminar(prof);
	}
	
	public boolean eliminar(int idProf) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.eliminar(idProf);
	}
}
