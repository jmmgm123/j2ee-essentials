package org.practica.facultad.gestion;
import java.util.List;

import org.practica.facultad.entidades.IProfesor;

public interface IProfesorDAO {
	
	public boolean registrar(IProfesor prof);
	public List<IProfesor> obtener();
	public IProfesor obtenerId(String id);
	public boolean actualizar(IProfesor prof);
	public boolean eliminar(IProfesor prof);
	public boolean eliminar(int idProf);
	public void listarResultados(List<IProfesor> ListProf);
	
}
