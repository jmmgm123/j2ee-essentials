package org.practica.facultad.paginas;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.practica.facultad.gestion.ControllerProfesor;

/**
 * Servlet implementation class ModificarProfesor
 */
@WebServlet("/EliminarProfesor")
public class EliminarProfesor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EliminarProfesor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("idProf"));

		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		String pathEstilos = request.getContextPath();
		
		//BBDD
		try {
			
			ControllerProfesor controllerProf = new ControllerProfesor();
			boolean actualizado = controllerProf.eliminar(id);
	        
			if(actualizado) {
		        out.println(correcto(pathEstilos));
			} else {
				out.println(incorrecto(pathEstilos));
			}
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private String correcto(String path) {
		String salida = 
        "<html>" + 
        "<head>" + 
        "<link rel=\'stylesheet\' href=\'" + path  + "/styles.css\'>" + 
        "</head>" + 
        "<body>" +
        "<form>" + 
        "<div class='fila'>" + 
        "<div class='col-100'>" + 
        "Se ha eliminado el profesor " + 
        "</div>" + 
        "</div>" + 
        "<div class='fila'>" + 
        "<div class='col-100 button'>" + 
        "<a href=\'/Practica_13_servletFacultad/GestorProfesor?&accion=listar'><button type=\'button\'>Aceptar</button></a>" + 
        "</div>" + 
        "</div>" + 
        "</form>" + 
        "</body>" + 
        "</html>";
		
		return salida;
		
	}

	private String incorrecto(String path) {
		String salida = 
        "<html>" + 
        "<head>" + 
        "<link rel=\'stylesheet\' href=\'" + path  + "/styles.css\'>" + 
        "</head>" + 
        "<body>" +
        "<form action='GestorProfesor'>"+ 
        "<div class='col-100'>" + 
        "No se ha podido eliminar al profesor " + 
        "</div>" + 
        "</div>" +
        "<div class='fila'>" + 
        "<div class='col-100 button'>" + 
        "<a href=\'/Practica_13_servletFacultad/GestorProfesor?&accion=listar'><button type=\'button\'>Volver</button></a>" + 
        "</div>" + 
        "</div>" + 
        "</form>" + 
        "</body>" + 
        "</html>";
		
		return salida;
		
	}

}
