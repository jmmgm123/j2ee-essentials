package org.practica.facultad.paginas;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.practica.facultad.entidades.IProfesor;

/**
 * Servlet implementation class GestorProfesor
 */
@WebServlet("/GestorProfesor")
public class GestorProfesor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestorProfesor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String accion = request.getParameter("accion");
		
		if(accion.equals("listar")){
			RequestDispatcher rd= getServletContext().getRequestDispatcher("/ListarProfesor");
			rd.include(request, response);
			
		} else if(accion.equals("index")){
			getServletContext().getRequestDispatcher("/index.html").forward(request, response);
			
		} else if(accion.equals("editar")){

			RequestDispatcher rd= getServletContext().getRequestDispatcher("/EditarProfesor");
			rd.include(request, response);
			
		} else if(accion.equals("eliminar")){
			
			RequestDispatcher rd= getServletContext().getRequestDispatcher("/EliminarProfesor");
			rd.include(request, response);
		}

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	//Dada una coleccion de numeros enteros, determinar cuantos son pares/impares
	//Quitar  los impares
}
