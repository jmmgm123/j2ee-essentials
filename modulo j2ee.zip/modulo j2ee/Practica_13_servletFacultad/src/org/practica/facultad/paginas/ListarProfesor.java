package org.practica.facultad.paginas;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.practica.facultad.entidades.IProfesor;
import org.practica.facultad.gestion.ControllerProfesor;

/**
 * Servlet implementation class ListarProfesor
 */
@WebServlet("/ListarProfesor")
public class ListarProfesor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListarProfesor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			
			ControllerProfesor controllerProf = new ControllerProfesor();
			List<IProfesor> ListProf  = controllerProf.obtener();
			String pathEstilos = request.getContextPath();
			
	       request.setAttribute("profesores", ListProf);
	       request.setAttribute("pathEstilos", pathEstilos);

	       getServletContext().getRequestDispatcher("/jsp/listadoProfesores.jsp").forward(request, response);
           			
		}catch(Exception e) {
			
			System.out.println(e.getMessage());
			e.printStackTrace();
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

