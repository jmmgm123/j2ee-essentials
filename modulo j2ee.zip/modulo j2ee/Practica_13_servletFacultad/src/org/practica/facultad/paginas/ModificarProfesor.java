package org.practica.facultad.paginas;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.practica.facultad.entidades.Departamento;
import org.practica.facultad.entidades.Empleado;
import org.practica.facultad.entidades.Fecha;
import org.practica.facultad.entidades.IProfesor;
import org.practica.facultad.entidades.Persona;
import org.practica.facultad.entidades.Profesor;
import org.practica.facultad.gestion.ControllerProfesor;

/**
 * Servlet implementation class ModificarProfesor
 */
@WebServlet("/ModificarProfesor")
public class ModificarProfesor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModificarProfesor() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		String nombre = request.getParameter("nombre");
		String apellido1 = request.getParameter("apellido1");
		String apellido2 = request.getParameter("apellido2");
		String dni = request.getParameter("dni");
		String estadoCivil = request.getParameter("estadoCivil");
		String departamento = request.getParameter("nombreDep");
		String numDespacho = request.getParameter("numDespacho");
		String anyoIncorporacion = request.getParameter("anyoIncorporacion");
		
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		String pathEstilos = request.getContextPath();
		
		Profesor prof = new Profesor(
				id, 
				new Persona(nombre, apellido1, apellido2, dni, estadoCivil),
				new Empleado(new Fecha(anyoIncorporacion), numDespacho),
				new Departamento(departamento));
		
		//BBDD
		try {
			
			ControllerProfesor controllerProf = new ControllerProfesor();
			boolean actualizado = controllerProf.actualizar(prof);
	        
			if(actualizado) {
		        out.println(correcto(prof, pathEstilos));
			} else {
				out.println(incorrecto(prof, pathEstilos));
			}
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private String correcto(Profesor p, String path) {
		String salida = 
        "<html>" + 
        "<head>" + 
        "<link rel=\'stylesheet\' href=\'" + path  + "/styles.css\'>" + 
        "</head>" + 
        "<body>" +
        "<form>" + 
        "<div class='fila'>" + 
        "<div class='col-100'>" + 
        "Se ha actualizado el profesor "+ p.getNombre() + " "  + p.getApellido1() + " " + p.getApellido2() + 
        "</div>" + 
        "</div>" + 
        "<div class='fila'>" + 
        "<div class='col-100 button'>" + 
        "<a href=\'/Practica_13_servletFacultad/GestorProfesor?&accion=listar'><button type=\'button\'>Aceptar</button></a>" + 
        "</div>" + 
        "</div>" + 
        "</form>" + 
        "</body>" + 
        "</html>";
		
		return salida;
		
	}

	private String incorrecto(Profesor p, String path) {
		String salida = 
        "<html>" + 
        "<head>" + 
        "<link rel=\'stylesheet\' href=\'" + path  + "/styles.css\'>" + 
        "</head>" + 
        "<body>" +
        "<form action='GestorProfesor'>"+ 
        "<div class='col-100'>" + 
        "No se ha actualizado al profesor "+ p.getNombre() + " "  + p.getApellido1() + " " + p.getApellido2() + 
        "</div>" + 
        "</div>" +
        "<div class='fila'>" + 
        "<div class='col-100 button'>" + 
        "<a href=\'/Practica_13_servletFacultad/GestorProfesor?&accion=listar'><button type=\'button\'>Volver</button></a>" + 
        "</div>" + 
        "</div>" + 
        "</form>" + 
        "</body>" + 
        "</html>";
		
		return salida;
		
	}

}
