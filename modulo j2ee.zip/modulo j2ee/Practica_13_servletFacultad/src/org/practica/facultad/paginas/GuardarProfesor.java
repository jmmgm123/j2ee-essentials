package org.practica.facultad.paginas;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.practica.facultad.entidades.Departamento;
import org.practica.facultad.entidades.Empleado;
import org.practica.facultad.entidades.Fecha;
import org.practica.facultad.entidades.Persona;
import org.practica.facultad.entidades.Profesor;
import org.practica.facultad.gestion.ControllerProfesor;

/**
 * Servlet implementation class GuardarProfesor
 */
@WebServlet("/GuardarProfesor")
public class GuardarProfesor extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GuardarProfesor(){
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre = request.getParameter("nombre");
		String dni = request.getParameter("dni");
		Profesor p = new Profesor();
		
		p.setNombre(nombre);
		p.setDni(dni);
		String pathEstilos = request.getContextPath();
		
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
		
		if((nombre!=null && !"".equals(nombre)) || (dni!=null && !"".equals(dni))) {
			
			String apellido1 = request.getParameter("apellido1");
			String apellido2 = request.getParameter("apellido2");
			String estadoCivil = request.getParameter("estadoCivil");
			String departamento = request.getParameter("departamento");
			String numDespacho = request.getParameter("numDespacho");
			String anyoIncorporacion = request.getParameter("anyoIncorporacion");

			p = new Profesor(
					0,
					new Persona(nombre, apellido1, apellido2, dni, estadoCivil),
					new Empleado(new Fecha(anyoIncorporacion), numDespacho),
					new Departamento(departamento));
			//BBDD
			try {
				
				ControllerProfesor controllerProf = new ControllerProfesor();
				boolean insertado = controllerProf.registrar(p);
		        
				if(insertado) {
			        out.println(correcto(p, pathEstilos));
				} else {
					out.println(incorrecto(p, pathEstilos));
				}
				
			}catch(Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
			
		} else {
			out.println(incorrecto(p, pathEstilos));
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private String correcto(Profesor p, String path) {
		String salida = 
        "<html>" + 
        "<head>" + 
        "<link rel=\'stylesheet\' href=\'" + path  + "/styles.css\'>" + 
        "</head>" + 
        "<body>" +
        "<form>" + 
        "<div class='fila'>" + 
        "<div class='col-100'>" + 
        "� Hola "+ p.getNombre() + " "  + p.getApellido1() + " " + p.getApellido2() + " !" + 
        "</div>" + 
        "</div>" + 
        "<div class='fila'>" + 
        "<div class='col-100'>" + 
        "Departamento "+ p.getNombreDep() + ", despacho: " + p.getNumDespacho() + 
        "</div>" + 
        "</div>" + 
        "<div class='fila'>" + 
        "<div class='col-100 button'>" + 
        "<a href=\'./index.html\'><button type=\'button\'>Volver al inicio</button></a>" + 
        "</div>" + 
        "</div>" + 
        "</form>" + 
        "</body>" + 
        "</html>";
		
		return salida;
		
	}

	private String incorrecto(Profesor p, String path) {
		String salida = 
        "<html>" + 
        "<head>" + 
        "<link rel=\'stylesheet\' href=\'" + path  + "/styles.css\'>" + 
        "</head>" + 
        "<body>" +
        "<form>"; 
        if(p.getDni()!=null && !"".equals(p.getDni())) {
	       salida += "<div class='fila'>" + 
	        "<div class='col-100'>" + 
	        "No se ha podido dar de alta al profesor "+ p.getNombre() + " "  + p.getApellido1() + " " + p.getApellido2()  + 
	        "</div>" + 
	        "</div>";
        } else {
        	salida += "<div class='fila'>" + 
        	        "<div class='col-100'>" + 
        	        " No ha introducido un Dni. "+ 
        	        "</div>" + 
        	        "</div>";
        }
        if(p.getNombre()!=null && !"".equals(p.getNombre())) {
 	       salida += "<div class='fila'>" + 
 	        "<div class='col-100'>" + 
 	        "No se ha podido dar de alta al profesor "+ p.getNombre() + " "  + p.getApellido1() + " " + p.getApellido2()  + 
 	        "</div>" + 
 	        "</div>";
         } else {
         	salida += "<div class='fila'>" + 
         	        "<div class='col-100'>" + 
         	        " No ha introducido un nombre. "+ 
         	        "</div>" + 
         	        "</div>";
         }
        salida +=  "<div class='fila'>" + 
        "<div class='col-100 button'>" + 
        "<a href=\'./jsp/alta_profesor.jsp\'><button type=\'button\'>Volver</button></a>" + 
        "</div>" + 
        "</div>" + 
        "</form>" + 
        "</body>" + 
        "</html>";
		
		return salida;
		
	}

}
