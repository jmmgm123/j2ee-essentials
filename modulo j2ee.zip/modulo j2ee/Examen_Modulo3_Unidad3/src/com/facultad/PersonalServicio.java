package com.facultad;

public class PersonalServicio implements IEmpleado, IPersona, ISeccion {

	private Persona pers;
	private Empleado empl;
	private Seccion secc;
	
	
	public PersonalServicio() {
	}
	
	/**
	 * @param pers - Persona
	 * @param empl - Empleado
	 * @param dept - Seccion
	 */
	public PersonalServicio(Persona pers, Empleado emp, Seccion secc) {
		this.pers = pers;
		this.empl = emp;
		this.secc = secc;
	}

	//Persona
	
	@Override
	public String getNombre() {
		return pers.getNombre();
	}

	@Override
	public void setNombre(String nombre) {
		pers.setNombre(nombre);
	}

	@Override
	public String getApellido1() {
		return pers.getApellido1();
	}

	@Override
	public void setApellido1(String apellido1) {
		pers.setApellido1(apellido1);
		
	}

	@Override
	public String getApellido2() {
		return pers.getApellido2();
	}

	@Override
	public void setApellido2(String apellido2) {
		pers.setApellido2(apellido2);
		
	}

	@Override
	public String getDni() {
		return pers.getDni(); 
	}

	@Override
	public void setDni(String dni) {
		pers.setDni(dni);
		
	}

	@Override
	public String getEstadoCivil() {
		return pers.getEstadoCivil();
	}

	@Override
	public void setEstadoCivil(String estadoCivil) {
		pers.setEstadoCivil(estadoCivil);
		
	}

	//fin Persona

	//Empleado

	@Override
	public Fecha getA�oIncorporacion() {
		return empl.getA�oIncorporacion();
	}
	
	@Override
	public void setA�oIncorporacion(Fecha a�oIncorporacion) {
		empl.setA�oIncorporacion(a�oIncorporacion); 
	}

	@Override
	public String getNumDespacho() {
		return empl.getNumDespacho();
	}

	@Override
	public void setNumDespacho(String numDespacho) {
		empl.setNumDespacho(numDespacho);
	}

	
	//fin Empelado
	
	//Seccion

	@Override
	public String getNombreSec() {
		return secc.getNombreSec();
	}

	@Override
	public void setNombreSec(String nombreSec) {
		secc.setNombreSec(nombreSec);
		
	}

	

	//fin Seccion


	@Override
	public String toString() {
		return "PersonalServicio [pers=" + pers.toString() + ", empl=" + empl.toString() + ", secc=" + secc.toString() + "]";
	}
	



}
