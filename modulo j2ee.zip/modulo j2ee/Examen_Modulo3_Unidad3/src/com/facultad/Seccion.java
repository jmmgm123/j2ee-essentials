package com.facultad;

public class Seccion implements ISeccion{

	private String nombreSec;

	
	public Seccion() {
	}
	
	/**
	 * @param nombreSec
	 */
	public Seccion(String nombreSec) {
		this.nombreSec = nombreSec;
	}

	public String getNombreSec() {
		return nombreSec;
	}

	public void setNombreSec(String nombreSec) {
		this.nombreSec = nombreSec;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seccion other = (Seccion) obj;
		if (nombreSec == null) {
			if (other.nombreSec != null)
				return false;
		} else if (!nombreSec.equals(other.nombreSec))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Seccion [nombreSec=" + nombreSec + "]";
	}
	
}
