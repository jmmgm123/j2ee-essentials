package com.facultad;

public class Profesor2 implements IEmpleado, IPersona, IDepartamento {

	private Persona pers;
	private Empleado empl;
	private Departamento dept;
	
	
	public Profesor2() {
		this.pers = new Persona();
		this.empl = new Empleado();
		this.dept = new Departamento();
	}
	
	/**
	 * @param pers - Persona
	 * @param empl - Empleado
	 * @param dept - Departamento
	 */
	public Profesor2(Persona pers, Empleado emp, Departamento dep) {
		this.pers = pers;
		this.empl = emp;
		this.dept = dep;
	}

	//Persona
	
	@Override
	public String getNombre() {
		return pers.getNombre();
	}

	@Override
	public void setNombre(String nombre) {
		pers.setNombre(nombre);
	}

	@Override
	public String getApellido1() {
		return pers.getApellido1();
	}

	@Override
	public void setApellido1(String apellido1) {
		pers.setApellido1(apellido1);
		
	}

	@Override
	public String getApellido2() {
		return pers.getApellido2();
	}

	@Override
	public void setApellido2(String apellido2) {
		pers.setApellido2(apellido2);
		
	}

	@Override
	public String getDni() {
		return pers.getDni(); 
	}

	@Override
	public void setDni(String dni) {
		pers.setDni(dni);
		
	}

	@Override
	public String getEstadoCivil() {
		return pers.getEstadoCivil();
	}

	@Override
	public void setEstadoCivil(String estadoCivil) {
		pers.setEstadoCivil(estadoCivil);
		
	}

	//fin Persona

	//Empleado

	@Override
	public Fecha getA�oIncorporacion() {
		return empl.getA�oIncorporacion();
	}
	
	@Override
	public void setA�oIncorporacion(Fecha a�oIncorporacion) {
		empl.setA�oIncorporacion(a�oIncorporacion); 
	}

	@Override
	public String getNumDespacho() {
		return empl.getNumDespacho();
	}

	@Override
	public void setNumDespacho(String numDespacho) {
		empl.setNumDespacho(numDespacho);
	}

	
	//fin Empelado
	
	//Departamento
	

	@Override
	public String getNombreDep() {
		return dept.getNombreDep();
	}

	@Override
	public void setNombreDep(String nombreDep) {
		dept.setNombreDep(nombreDep);
		
	}


	
	//fin Departamento


	@Override
	public String toString() {
		return "Profesor [pers=" + pers.toString() + ", mpl=" + empl.toString() + ", dept=" + dept.toString() + "]";
	}	
	



}
