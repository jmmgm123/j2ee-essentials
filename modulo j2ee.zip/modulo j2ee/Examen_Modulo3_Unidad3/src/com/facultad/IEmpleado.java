package com.facultad;

public interface IEmpleado {

	public Fecha getA�oIncorporacion();

	public void setA�oIncorporacion(Fecha a�oIncorporacion);

	public String getNumDespacho();

	public void setNumDespacho(String numDespacho); 
	
}
