package com.facultad;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CursoDaoImp implements ICursoDAO {

	@Override
	public boolean registrar(Curso curso) {
		boolean registrar = false;

		BD bd = new BD();

		String sql = "INSERT INTO `curso` (`nomCurso`) VALUES ('"
				+ curso.getNombreCurso() +"')";

		try {
			if (bd.doUpdate(sql) > 0) {
				registrar = true;
			} else {
				registrar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase CursoDaoImpl, m�todo registrar");
			registrar = false;
			e.printStackTrace();
		}
		return registrar;
	}

	@Override
	public List<Curso> obtener() {

		BD bd = new BD();

		String sql = "SELECT * FROM `curso`";

		List<Curso> listaCursos = new ArrayList<Curso>();
		int i = 0;
		try {
			ResultSet rs = bd.doQuery(sql);
			while (rs.next()) {
				Curso cur = new Curso();
				cur.setId(rs.getInt(1));
				cur.setNombreCurso(rs.getString(2));
				listaCursos.add(cur);
			}
			bd.finish();
		} catch (SQLException e) {
			System.out.println("Error: Clase CursoDaoImpl, m�todo obtener");
			e.printStackTrace();
		}

		return listaCursos;
	}

	public void listarResultados(List<Curso> ListCursos) {
		Iterator iter = ListCursos.iterator();
		while (iter.hasNext())
			System.out.println(iter.next());
	}

	@Override
	public boolean actualizar(Curso curso) {

		BD bd = new BD();

		boolean actualizar = false;

		String sql = "UPDATE `curso` SET " + "nomCurso='" + curso.getNombreCurso() +
				"'" + " WHERE id='" + curso.getId() + "'";

		try {
			if (bd.doUpdate(sql) > 0) {
				actualizar = true;
			} else {
				actualizar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase CursoDaoImple, m�todo actualizar");
			e.printStackTrace();
			actualizar = false;
		}
		return actualizar;
	}

	@Override
	public boolean eliminar(int id) {
		
		BD bd = new BD();

		boolean eliminar = false;

		String sql = "DELETE FROM `curso` WHERE id=" + id;
		try {
			if (bd.doUpdate(sql)>0)
				eliminar = true;
			else 
				eliminar = false;
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase CursoDaoImpl, m�todo eliminar");
			e.printStackTrace();
		}
		return eliminar;
	}

	public Curso obtenerId(int id) {
		BD bd = new BD();

		String sql = "SELECT * FROM `curso` where id=" + id;

		Curso curso = new Curso();
		
		int i = 0;
		try {
			ResultSet rs = bd.doQuery(sql);
			while (rs.next()) {
				
				curso.setId(rs.getInt(1));
				curso.setNombreCurso(rs.getString(2));
			}
			bd.finish();
		} catch (SQLException e) {
			System.out.println("Error: Clase CursoDaoImpl, m�todo obtenerId");
			e.printStackTrace();
		}

		return curso;
	}
}
