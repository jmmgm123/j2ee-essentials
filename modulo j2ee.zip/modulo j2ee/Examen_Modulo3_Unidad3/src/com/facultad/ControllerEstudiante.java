package com.facultad;
import java.util.List;

public class ControllerEstudiante {
	
	public ControllerEstudiante() {
	}
	
	//llama al DAO para guardar un cliente
	public boolean registrar(Estudiante estudiante ) {
		IEstudianteDAO dao= new EstudianteDaoImp();
		return dao.registrar(estudiante);
	}
	
	public List<Estudiante> obtener(){
		IEstudianteDAO dao= new EstudianteDaoImp();
		return dao.obtener();
	}
	
	public void listarResultados(List<Estudiante> ListEst) {
		IEstudianteDAO dao= new EstudianteDaoImp();
		dao.listarResultados(ListEst);
	}
	
	public static boolean actualizar(Estudiante estudiante) {
		IEstudianteDAO dao= new EstudianteDaoImp();
		return dao.actualizar(estudiante);
	}
	
	public boolean eliminar(int id) {
		IEstudianteDAO dao= new EstudianteDaoImp();
		return dao.eliminar(id);
	}
	
	public static Estudiante obtenerId(int id){
		IEstudianteDAO dao= new EstudianteDaoImp();
		return dao.obtenerId(id);
	}
}
