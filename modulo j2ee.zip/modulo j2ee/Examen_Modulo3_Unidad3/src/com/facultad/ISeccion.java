package com.facultad;

public interface ISeccion {
	
	public String getNombreSec();

	public void setNombreSec(String nombreSec);

}
