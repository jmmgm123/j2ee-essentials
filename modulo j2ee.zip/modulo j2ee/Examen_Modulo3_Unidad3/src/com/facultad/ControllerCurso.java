package com.facultad;
import java.util.List;

public class ControllerCurso {
	
	public ControllerCurso() {
	}
	
	//llama al DAO para guardar un cliente
	public boolean registrar(Curso curso ) {
		ICursoDAO dao= new CursoDaoImp();
		return dao.registrar(curso);
	}
	
	public List<Curso> obtener(){
		ICursoDAO dao= new CursoDaoImp();
		return dao.obtener();
	}
	
	public void listarResultados(List<Curso> ListCurso) {
		ICursoDAO dao= new CursoDaoImp();
		dao.listarResultados(ListCurso);
	}
	
	public boolean actualizar(Curso curso) {
		ICursoDAO dao= new CursoDaoImp();
		return dao.actualizar(curso);
	}
	
	public boolean eliminar(int id) {
		ICursoDAO dao= new CursoDaoImp();
		return dao.eliminar(id);
	}
	
	public Curso obtenerId(int id){
		ICursoDAO dao= new CursoDaoImp();
		return dao.obtenerId(id);
	}
}
