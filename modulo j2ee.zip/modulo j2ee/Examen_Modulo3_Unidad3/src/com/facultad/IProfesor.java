package com.facultad;

public interface IProfesor extends IPersona, IEmpleado, IDepartamento {

}
