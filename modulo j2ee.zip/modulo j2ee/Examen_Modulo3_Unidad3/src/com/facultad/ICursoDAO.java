package com.facultad;
import java.util.List;

public interface ICursoDAO {
	public boolean registrar(Curso curso);
	public List<Curso> obtener();
	public Curso obtenerId(int id);
	public boolean actualizar(Curso curso);
	public boolean eliminar(int id);
	public void listarResultados(List<Curso> ListCurso);
}
