package com.facultad;
import java.util.List;

public interface IProfesorDAO {
	public boolean registrar(IProfesor cliente);
	public List<IProfesor> obtener();
	public IProfesor obtenerId(int id);
	public boolean actualizar(IProfesor prof);
	public boolean eliminar(int id);
	public void listarResultados(List<IProfesor> ListProf);
}
