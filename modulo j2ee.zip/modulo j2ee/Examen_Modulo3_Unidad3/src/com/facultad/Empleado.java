package com.facultad;

public class Empleado  implements IEmpleado{

	private Fecha a�oIncorporacion;
	private String numDespacho;


	public Empleado() {
	}
	
	/**
	 * @param a�oIncorporacion
	 * @param numDespacho
	 */
	public Empleado(Fecha a�oIncorporacion, String numDespacho) {

		this.a�oIncorporacion = a�oIncorporacion;
		this.numDespacho = numDespacho;
	}

	public Fecha getA�oIncorporacion() {
		return a�oIncorporacion;
	}

	public void setA�oIncorporacion(Fecha a�oIncorporacion) {
		this.a�oIncorporacion = a�oIncorporacion;
	}

	public String getNumDespacho() {
		return numDespacho;
	}

	public void setNumDespacho(String numDespacho) {
		this.numDespacho = numDespacho;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		if (a�oIncorporacion == null) {
			if (other.a�oIncorporacion != null)
				return false;
		} else if (!a�oIncorporacion.equals(other.a�oIncorporacion))
			return false;
		if (numDespacho == null) {
			if (other.numDespacho != null)
				return false;
		} else if (!numDespacho.equals(other.numDespacho))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Empleado [a�oIncorporacion=" + a�oIncorporacion.toString() + ", numDespacho=" + numDespacho + "]";
	}
	
	
	
	
	
	
}
