
public class CuentaBancaria {

	private String nombre;
	private String apellidos;
	private String nCuenta;
	private String dni;
	private int saldo;
	
	
	public CuentaBancaria() {
		this.nombre = "";
		this.apellidos = "";
		this.nCuenta = "";
		this.dni = "";
		this.saldo = 0;
	}

	public CuentaBancaria(String nombre, String apellidos, String nCuenta, String dni, int saldo) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.nCuenta = nCuenta;
		this.dni = dni;
		this.saldo = saldo;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}
	
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	public String getnCuenta() {
		return nCuenta;
	}
	
	public void setnCuenta(String nCuenta) {
		this.nCuenta = nCuenta;
	}
	
	public String getDni() {
		return dni;
	}
	
	public void setDni(String dni) {
		this.dni = dni;
	}
	
	public int getSaldo() {
		return saldo;
	}
	
	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

	@Override
	public String toString() {
		return "Cuenta Bancaria [nombre=" + nombre + ", apellidos=" + apellidos + ", nCuenta=" + nCuenta + ", dni=" + dni
				+ ", saldo=" + saldo + "]";
	}
	
	
	
}
