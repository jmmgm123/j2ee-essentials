
public class MainReloj {

	public static void main(String[] args) {
		
/*		
  	System.out.println("---- Puntos ----------");
		
		Punto p1 = new Punto(3.2, 36.5);
		Punto p2 = new Punto();
		

		System.out.println("Objeto p1: " + p1.toString());
		System.out.println("Objeto p2: " + p2.toString());
		
		System.out.println("Valor y: " + p1.getY());
		
		
		p1.setY(0.4);
		
		System.out.println("Valor y: " + p1.getY());
		
		p2.setY(222);
		p1.setX(0.0);
		
		System.out.println("Objeto p2: " + p2.toString());
		
		System.out.println(p1.getX() == p2.getX());
		
		System.out.println("---- Fechas ----------");
		
		Fecha f1 = new Fecha();
		Fecha f2 = new Fecha(12, 12, 1920);
		
		System.out.println(f1.aTexto());
		System.out.println(f2.aTexto());
		
		f1.setAnio(1985);
		
		System.out.println(f1.aTexto());
		
		Horario h1 = new Horario(12,12,18);
		
		Reloj r1 = new Reloj(f1, h1);
		
		System.out.println("reloj... " + r1.toString());
		
		System.out.println(f2.aTexto() + " - " + LibFecha.diasDelMes(f2));
*/
		
		//Dados dos relojes hay que calcular cuantos dias han pasado
		
		//Dado dos relojes hay que calcular si un reloj es menor que otro
		
//		System.out.println("Dado dos relojes hay que calcular si un reloj es menor que otro");
//		
//		Reloj r1 = new Reloj(new Fecha(1, 3, 2020), new Horario(21, 00, 59));
//		Reloj r2 = new Reloj(new Fecha(1, 3, 2020), new Horario(12, 32, 30));
//		
//		System.out.println("Es menor r1 que r2..." + LibHorario.esAnterior(r1.getHorario(), r2.getHorario()));
//		System.out.println("Es igual r1 que r2..." + LibHorario.esIgual(r1.getHorario(), r2.getHorario()));
//		System.out.println("Como es el horario de r1 frente a r2..." + LibHorario.comparaHorarios(r1.getHorario(), r2.getHorario()));
//		System.out.println("Como es la fecha de r1 frente a r2..." + LibFecha.comparaFechas(r1.getFecha(), r2.getFecha()));
//		System.out.println("Como es el reloj r1 frente a r2..." + LibReloj.comparaReloj(r1, r2));
//		
//		//Segundos entre horarios
//		
//		System.out.println("Segundos entre r1 y r2... " + LibHorario.diferenciaEnSegundos(r1.getHorario(), r2.getHorario()));
//		
//		//en 60 minutos
//		
//		System.out.println("en 60 minutos en r1 y r2... " + LibHorario.diferenciaEnSegundos(r1.getHorario(), r2.getHorario()));
//		
//		//Siguiente reloj
		Reloj r1 = new Reloj(new Fecha(31, 12, 2020), new Horario(23, 59, 30));
		
		System.out.println("El reloj marca...  " + r1.toString());
		//System.out.println("siguiente reloj... " + LibReloj.siguienteReloj(r1));
		
		LibReloj.mostarUnMinuto(r1);
	}

}
