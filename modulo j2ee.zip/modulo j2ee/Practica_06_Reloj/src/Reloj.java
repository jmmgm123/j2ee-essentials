
public class Reloj {
	
	Fecha fecha;
	Horario horario;
	
	public Reloj(Fecha fecha, Horario horario) {
		this.fecha = fecha;
		this.horario = horario;
	}

	public Fecha getFecha() {
		return fecha;
	}

	public void setFecha(Fecha fecha) {
		this.fecha = fecha;
	}

	public Horario getHorario() {
		return horario;
	}

	public void setHorario(Horario horario) {
		this.horario = horario;
	}

	public String toString() {
		return fecha.aTexto() + " - " + horario.aTexto();
	}
	
	
	
	
}
