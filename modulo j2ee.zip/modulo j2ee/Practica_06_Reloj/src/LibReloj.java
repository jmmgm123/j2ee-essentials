
public class LibReloj {

	public static String comparaReloj(Reloj r1, Reloj r2) 
	{
			
		String comparacion;
		String  compFechas = LibFecha.comparaFechas(r1.getFecha(), r2.getFecha());
		if(compFechas.equals("Iguales")) {
			comparacion = LibHorario.comparaHorarios(r1.getHorario(), r2.getHorario());
		} else {
			comparacion = compFechas;
		}
		
		return comparacion;
	}
	
	public static boolean relojCorrecto(Reloj r) 
	{
		return LibFecha.fechaCorrecta(r.getFecha()) && LibHorario.horarioCorrecto(r.getHorario());
	}
	

	public static Reloj siguienteReloj(Reloj r) 
	{
		Horario horarioCeros = new Horario(0,0,0);
		Fecha fechaCeros = new Fecha(0,0,0);
		
		if(LibFecha.fechaCorrecta(r.getFecha()) && LibHorario.horarioCorrecto(r.getHorario())) {
			Horario h = LibHorario.siguienteHorario(r.getHorario());
			if (h.igual(horarioCeros)) {
				Fecha f = LibFecha.siguienteFecha(r.getFecha());
				r.setFecha(f);
				r.setHorario(h);
			} else {
				r.setHorario(h);
			}
		} else {
			r.setFecha(fechaCeros);
			r.setHorario(horarioCeros);
		}
		return r;		
	}
	
	
	public static void mostarUnMinuto(Reloj r) {
		for(int i = 1; i<=60; i++) {
			
			System.out.println((siguienteReloj(r)).toString());
			
		}
	}
	
}
