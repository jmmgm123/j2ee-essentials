
public class Punto {

	//atributos -> estado
	private double x;
	private double y;
	
	public Punto() { //constructor por defecto de la clase Punto
		x = 0.0;
		y = 0.0;
	}
	
	public Punto (double unaX, double unaY){ //constructor natural -> tiene los mismo parametro que la clase
		x = unaX;
		y = unaY;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setX(double valorX) {
		x = valorX;
	}

	public void setY(double valorY) {
		y = valorY;
	}
	
	public String toString() {
		return "Punto - x: " + x + " / y: " + y;
	}

	
}
