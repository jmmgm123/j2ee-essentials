
public class Alumno {
  
	public int numero;
	public String nombre;
	public String apellidos;
	
	public Alumno ()
	{}
	public Alumno (int n, String nm, String a)
	{
		numero = n;
		nombre = nm;
		apellidos = a;
	}
	public String toString ()
	{
		return "N� " + numero + ", Nombre: " + nombre + ", Apellido: " + apellidos;
	}
}
