import java.sql.ResultSet;


public class MainBBDD {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		BD bd = new BD();
		Alumno [] colAl = new Alumno [10];
		String query2 = "INSERT INTO `curso`.`alumnos` (`NALUMNO`, `NOMBRE`, `APELLIDOS`) VALUES ('154', 'LUIS', 'MARTINEZ')";
		bd.doUpdate (query2);
		String query = "SELECT * FROM `alumnos` ";
		try
        { 
		
        ResultSet rs = bd.doQuery (query);
        
        int i = 0;
        while (rs.next())        
        {
           Alumno a = new Alumno();
           a.numero = new Integer(rs.getString(1));
           a.nombre = rs.getString(2);
           a.apellidos = rs.getString (3);
           colAl [i] = a;
           //System.out.println (a);
           i++;
        }
        bd.finish();
        // lo escribo otra vez para ver que lo tengo en el array !!!
        System.out.println("Contenido del array creado...");
        for (int j=0; j < i; j++)
        	System.out.println (colAl[j]);

//        conexion.close();
    }
    catch (Exception e)
    {
    	Error error = new Error ("3");
//		error.setErrorInf (new BRSAttribute ("message", e.toString()));
		throw new Exception (error);
    }
	
	}

}
