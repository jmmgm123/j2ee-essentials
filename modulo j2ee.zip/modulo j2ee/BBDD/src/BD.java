

import java.sql.*;
public class BD
{
  private Connection con;
  private Statement stmt;
  private ResultSet result;
  private ResultSetMetaData rsmd;
 
  public void registerDriver ()
  {
    String driver_jdbc_odbc="sun.jdbc.odbc.JdbcOdbcDriver";
    String driver_jdbc="com.mysql.cj.jdbc.Driver";
    try
    {
      System.err.println ("Class.forName");
      Class.forName (driver_jdbc);
    }
    catch (Exception e)
    {
      System.out.println (e);
      System.exit(0);
    }
  }
 
  public void connect (String url,String user,String pass)
  {
    try
    {
      con=DriverManager.getConnection (url,user,pass);
    }
    catch (SQLException e)
    {
      System.out.println (e);
      System.exit (0);
    }
  }
 
  public String getConnectionInfo()
  {
    DatabaseMetaData databaseMetaData;
    String s=null;
    try
    {
      databaseMetaData=con.getMetaData();
      s=" DB url: "+databaseMetaData.getURL();
      s+="<br/> Product name: "+databaseMetaData.getDatabaseProductName();
      s+="<br/> Product version: "+databaseMetaData.getDatabaseProductVersion();
      s+="<br/> Driver name: "+databaseMetaData.getDriverName();
      s+="<br/> Driver version: "+databaseMetaData.getDriverVersion()+"<br/>";
      //return s;
    }
    catch (SQLException e){}
    return s;
  }
 
  public void createStatement ()
  {
    try
    {
      stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
    }
    catch (SQLException e)
    {
      System.out.println (e);
      System.exit (0);
    }
  }
 
  public ResultSet doQuery (String sql)
  {
    createStatement ();
    try
    {
      result=stmt.executeQuery (sql);
    }
    catch (SQLException e)
    {
      System.out.println (e);
    }
    return result;
  }
 
  public int getNumCols()
  {
     int numberOfColumns=0;
     try
     {
        if (result!=null)
        {
          rsmd = result.getMetaData();
          numberOfColumns = rsmd.getColumnCount();
        }
     }
     catch (SQLException e)
     {
      System.out.println (e);
     }
     return numberOfColumns;
  }
 
  public String[] getColumnLabels ()
  {
    String[] labels=null;
     try
     {
        if (result!=null)
        {
          int numberOfColumns=getNumCols();
          labels=new String [numberOfColumns];
          rsmd = result.getMetaData();
          for (int i=0;i<getNumCols();i++)
            labels[i]=rsmd.getColumnLabel(i+1);
        }
     }
     catch (SQLException e)
     {
      System.out.println (e);
     }
     return labels;
  }
 
  public int doUpdate (String sql)
  {
    int n=0;
    createStatement ();
    try
    {
      n=stmt.executeUpdate (sql);
    }
    catch (SQLException e)
    {
      System.out.println (e);
    }
    return n;
  }
 
  public void finish()
  {
    try
    {
      if (result!=null) result.close();
      if (stmt!=null) stmt.close();
      if (con!=null) con.close();
    }
    catch (SQLException e)
    {
      System.out.println (e);
    }
  }
 
  public BD ()
  {
    registerDriver();
    //connect ("jdbc:odbc:DRIVER={Microsoft Access Driver (*.mdb)};DBQ=C:/Documents and Settings/alumno/Mis documentos/descargas/JDBC/EjemploBD.mdb");
    //connect ("jdbc:odbc:DRIVER={MySQL ODBC 5.1 Driver};SERVER=localhost;DATABASE=test;UID=java");
     //connect ("jdbc:mysql://192.168.64.2:3306/carnets &useSSL=false","root","");
    connect ("jdbc:mysql://localhost:3306/curso","root","");
    //connect ("jdbc:odbc:MySQL","root","");
  }
}