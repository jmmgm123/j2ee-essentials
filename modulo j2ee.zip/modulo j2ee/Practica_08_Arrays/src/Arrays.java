
public class Arrays {

	public static void main(String[] args) {

		Fecha f1 = new Fecha(23,12,1312);
		Fecha f2 = new Fecha(2,1,1223);
		Fecha f3 = new Fecha(3,11,2011);
		Fecha f4 = new Fecha(23,1,1951);
		
		Fecha[] fechas = {f1, f2};
		Fecha[][] fechas2 = {
							{f1, f2},
							{f3, f4}
							};
		
		Fechas[] fechas3 = new Fecha[3]

		//System.out.println (LibRdm.toString(fechas2));
		System.out.println ("La suma de a�os es: " + LibArrays.sumaAnio(fechas));
		
		for (Fecha[] innerArray: fechas2) {
	        for(Fecha fecha: innerArray) {
	           System.out.println(fecha);
	        }
	     }
		
		System.out.println("11." + fechas[0]);
	}
}
