import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

// Liber�a con clase Fecha

public class LibHorarios {

	//  DECLARACIONES DE CONSTANTES  ------------------------------------ 

	static final int segundosHora = 3600;
	static final int segundosMinuto = 60;
	static final int minutosHora = 60;
	static final int horasDias = 24;

	public static int aSegundos (Horario t)
	{
		return t.getHora() * segundosHora + t.getMinutos() * segundosMinuto + t.getSegundos();
	}

	public static boolean esAnterior (Horario t1, Horario t2)
	{
		final boolean mismaHora = t1.getHora() == t2.getHora();
		final boolean mismoMinuto = t1.getMinutos() == t2.getMinutos();
		return (t1.getHora() < t2.getHora()) ||
				(mismaHora && (t1.getMinutos() < t2.getMinutos())) ||
				(mismaHora && mismoMinuto && (t1.getSegundos() < t2.getSegundos()));
	}
	
	public static boolean esIgual (Horario t1, Horario t2)
	{
		final boolean mismaHora = t1.getHora() == t2.getHora();
		final boolean mismoMinuto = t1.getMinutos() == t2.getMinutos();
		final boolean mismosegundo = t1.getSegundos() == t2.getSegundos();
		return mismaHora && mismoMinuto && mismosegundo;
	}
	
	public static String comparaHorarios(Horario t1, Horario t2) {
		
		String comparacion = "posterior";
		if(esIgual(t1, t2)) {
			comparacion = "Iguales";
		} else if(esAnterior(t1, t2) == true) {
			comparacion = "anterior";
		}
		return comparacion;
	}
	
	public static boolean en60Minutos (Horario t1, Horario t2)
	{
//		if (esAnterior (t1, t2))
//			return ((t1.getHora() + 1) > t2.getHora()) ||
//					(((t1.getHora() + 1) == t2.getHora()) && (t1.getMinutos() > t2.getMinutos())) ||
//					(((t1.getHora() + 1) == t2.getHora()) && (t1.getMinutos() == t2.getMinutos()) && (t1.getSegundos() > t2.getSegundos()));
//		else
//			return ((t2.getHora() + 1) > t1.getHora()) ||
//					(((t2.getHora() + 1) == t1.getHora()) && (t2.getMinutos() > t1.getMinutos())) ||
//					(((t2.getHora() + 1) == t1.getHora()) && (t2.getMinutos() == t1.getMinutos()) && (t2.getSegundos() > t1.getSegundos()));
		
		if(!esAnterior(t1, t2)) {
			return false;
		} else {
			return diferenciaEnSegundos(t1, t2) <= segundosHora;
		}
		
	}

	public static boolean enLosMismos60Minutos (Horario t1, Horario t2)
	{
		if (((t1.getHora() == 0) && (t2.getHora() == 23)) || ((t1.getHora() == 23) && (t2.getHora() == 0))) {
			t1.setHora(t1.getHora()%24);
			t2.setHora(t2.getHora()%24);
			return en60Minutos (t1,t2);
		} else {
			return en60Minutos (t1,t2);
		}
	} 
	
	public static int diferenciaEnSegundos(Horario h1, Horario h2 ) 
	{
		return Math.abs(aSegundos(h1) - aSegundos(h2));
	}
	
	public static Horario siguienteHorario(Horario h)
	{
		int hora = h.getHora();
		int minutos = h.getMinutos();
		int segundos = h.getSegundos();
		Horario newHorario = new Horario();
		
//		if(segundos < segundosMinuto) {
//			return new Horario(hora, minutos, segundos+1);
//		} else if (minutos < segundosMinuto){
//			return new Horario(hora, minutos+1, segundos);
//		} else {
//			return new Horario(hora+1, minutos, segundos);
//		}
		
		if(segundos==segundosMinuto-1) {
			minutos++;
			segundos = 0;

			if( minutos==minutosHora) {
				hora++;
				minutos = 0;
				
				if(hora == horasDias){
					hora=0;
				}
			} 
			
		} else if(segundos<segundosMinuto) {
			segundos++;
		}
		
		newHorario.setHora(hora);
		newHorario.setMinutos(minutos);
		newHorario.setSegundos(segundos);
		
		return newHorario;
	}
	
	public static boolean horaCorrecta(int hora) {
		return 0 <= hora && hora < 24; 
	}
	
	public static boolean minutosCorrectos(int minutos) {
		return 0 <= minutos && minutos < 60; 
	}
	
	public static boolean segundosCorrectos(int segundos) {
		return 0 <= segundos && segundos < 60; 
	}
	
	public static boolean horarioCorrecto(Horario h) {
		return horaCorrecta(h.getHora()) && minutosCorrectos(h.getMinutos()) && segundosCorrectos(h.getSegundos()); 
	}
	
}

