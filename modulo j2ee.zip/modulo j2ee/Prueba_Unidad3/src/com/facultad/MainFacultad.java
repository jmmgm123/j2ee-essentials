package com.facultad;

public class MainFacultad {
	
	public static void main(String[] args) {

	
		Profesor[] profesores = new Profesor[3];
	
		profesores[0] = new Profesor(
				"Luis", "Rodriguez", "Albiol", "21544454P", "Soltero", "Historia",
				"12/10/2000", "100");
		
		profesores[1] = new Profesor(
				"Maria", "Leal", "Casado", "21544454P", "Soltero", "Ingles",
				"01/01/2019", "12B");
		
		profesores[2] = new Profesor(
				"Luisa", "Martinez", "Rubiales", "12354445K", "Casado", "Informatica",
				"12/10/2000", "100");		
		
		//BBDD
		try {
			
			ControllerProfesor controllerProf = new ControllerProfesor();
			//dar de alta un profesor
			System.out.println(controllerProf.registrar(profesores[0]));
			
			//obtener los profesores de la BBDD
			controllerProf.listarResultados(controllerProf.obtener());
			
			//actualizar profesor
//		   Profesor prof = controllerProf.obtenerPorId(13);
//		   prof.setApellido1("Luz");
//		   System.out.println(controllerProf.actualizar(prof));
		   
		   //System.out.println(controllerProf.eliminar(13));
			
		   controllerProf.listarResultados(controllerProf.obtener());
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

	}

}
