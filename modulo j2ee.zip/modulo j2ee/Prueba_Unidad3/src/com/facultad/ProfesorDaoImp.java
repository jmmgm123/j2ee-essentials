package com.facultad;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProfesorDaoImp implements IProfesorDAO {

	@Override
	public boolean registrar(Profesor prof) {
		boolean registrar = false;

		BD bd = new BD();

		String sql = "INSERT INTO `profesor`(`nombre`, `apellido1`, `apellido2`, `dni`, `estadoCivil`, `a�oImcorporacion`, `nDespacho`, `departamento`) VALUES ('"
				+ prof.getNombre() + "','" + prof.getApellido1() + "','" + prof.getApellido2() + "','" + prof.getDni()
				+ "','" + prof.getEstadoCivil() + "','" + prof.getA�oIncorporacion() + "','" + prof.getNumDespacho()
				+ "','" + prof.getNombreDep() + "')";

		try {
			if (bd.doUpdate(sql) > 0) {
				registrar = true;
			} else {
				registrar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo registrar");
			registrar = false;
			e.printStackTrace();
		}
		return registrar;
	}

	@Override
	public List<Profesor> obtener() {

		BD bd = new BD();

		String sql = "SELECT * FROM `profesor`";

		List<Profesor> listaProfesor = new ArrayList<Profesor>();
		int i = 0;
		try {
			ResultSet rs = bd.doQuery(sql);
			while (rs.next()) {
				Profesor prof = new Profesor();
				prof.setId(rs.getInt(1));
				prof.setNombre(rs.getString(2));
				prof.setApellido1(rs.getString(3));
				prof.setApellido2(rs.getString(4));
				prof.setDni(rs.getString(5));
				prof.setEstadoCivil(rs.getString(6));
				prof.setA�oIncorporacion(rs.getString(7));
				prof.setNumDespacho(rs.getString(8));
				prof.setNombreDep(rs.getString(9));
				listaProfesor.add(prof);
			}
			bd.finish();
		} catch (SQLException e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo obtener");
			e.printStackTrace();
		}

		return listaProfesor;
	}
	
	public Profesor obtenerPorID(int id) {
		BD bd = new BD();
		Profesor prof = new Profesor();
		
		String sql = "SELECT * FROM `profesor` where id=" + id;

		try {
			ResultSet rs = bd.doQuery(sql);
			while (rs.next()) {
				prof.setId(rs.getInt(1));
				prof.setNombre(rs.getString(2));
				prof.setApellido1(rs.getString(3));
				prof.setApellido2(rs.getString(4));
				prof.setDni(rs.getString(5));
				prof.setEstadoCivil(rs.getString(6));
				prof.setA�oIncorporacion(rs.getString(7));
				prof.setNumDespacho(rs.getString(8));
				prof.setNombreDep(rs.getString(9));
			}
			bd.finish();
		} catch (SQLException e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo obtener");
			e.printStackTrace();
		}

		return prof;
	}

	public void listarResultados(List<Profesor> ListProf) {
		Iterator iter = ListProf.iterator();
		while (iter.hasNext())
			System.out.println(iter.next());
	}

	@Override
	public boolean actualizar(Profesor prof) {

		BD bd = new BD();

		boolean actualizar = false;

		String sql = "UPDATE `profesor` SET " + "nombre='" + prof.getNombre() + "', apellido1='" + prof.getApellido1()
				+ "', apellido2='" + prof.getApellido2() +
				// "', dni='"+prof.getDni()+
				"', estadoCivil='" + prof.getEstadoCivil() + "', a�oImcorporacion='" + prof.getA�oIncorporacion()
				+ "', nDespacho='" + prof.getNumDespacho() + "', departamento='" + prof.getNombreDep() +

				"'" + " WHERE dni='" + prof.getDni() + "'";

		try {
			if (bd.doUpdate(sql) > 0) {
				actualizar = true;
			} else {
				actualizar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo actualizar");
			e.printStackTrace();
			actualizar = false;
		}
		return actualizar;
	}

	@Override
	public boolean eliminar(int id) {
		
		BD bd = new BD();

		boolean eliminar = false;

		String sql = "DELETE FROM `profesor` WHERE id=" + id;
		try {
			if (bd.doUpdate(sql)>0)
				eliminar = true;
			else 
				eliminar = false;
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo eliminar");
			e.printStackTrace();
		}
		return eliminar;
	}

}
