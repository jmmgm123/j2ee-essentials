package com.facultad;
import java.util.List;

public interface IProfesorDAO {
	public boolean registrar(Profesor cliente);
	public List<Profesor> obtener();
	public Profesor obtenerPorID(int id);
	public boolean actualizar(Profesor prof);
	public boolean eliminar(int id);
	public void listarResultados(List<Profesor> ListProf);
}
