package com.facultad;

public class Profesor {

	private int id;
	private String nombre;
	private String apellido1;
	private String apellido2;
	private String dni;
	private String estadoCivil;
	private String nombreDep;
	private String a�oIncorporacion;
	private String numDespacho;


	public Profesor() {
	}


	public Profesor(String nombre, String apellido1, String apellido2, String dni, String estadoCivil, String nombreDep,
			String a�oIncorporacion, String numDespacho) {
		super();
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
		this.dni = dni;
		this.estadoCivil = estadoCivil;
		this.nombreDep = nombreDep;
		this.a�oIncorporacion = a�oIncorporacion;
		this.numDespacho = numDespacho;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido1() {
		return apellido1;
	}


	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}


	public String getApellido2() {
		return apellido2;
	}


	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}


	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public String getEstadoCivil() {
		return estadoCivil;
	}


	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}


	public String getNombreDep() {
		return nombreDep;
	}


	public void setNombreDep(String nombreDep) {
		this.nombreDep = nombreDep;
	}


	public String getA�oIncorporacion() {
		return a�oIncorporacion;
	}


	public void setA�oIncorporacion(String a�oIncorporacion) {
		this.a�oIncorporacion = a�oIncorporacion;
	}


	public String getNumDespacho() {
		return numDespacho;
	}


	public void setNumDespacho(String numDespacho) {
		this.numDespacho = numDespacho;
	}


	@Override
	public String toString() {
		return "Profesor [id=" + id + ", nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", dni=" + dni
				+ ", estadoCivil=" + estadoCivil + ", nombreDep=" + nombreDep + ", a�oIncorporacion=" + a�oIncorporacion
				+ ", numDespacho=" + numDespacho + "]";
	}	
	
	
}
