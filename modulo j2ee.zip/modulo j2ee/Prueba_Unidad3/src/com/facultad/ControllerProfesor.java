package com.facultad;
import java.util.List;

public class ControllerProfesor {
	
	public ControllerProfesor() {
	}
	
	//llama al DAO para guardar un cliente
	public boolean registrar(Profesor profesor ) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.registrar(profesor);
	}
	
	public List<Profesor> obtener(){
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.obtener();
	}
	
	public Profesor obtenerPorId(int id){
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.obtenerPorID(id);
	}
	
	public void listarResultados(List<Profesor> ListProf) {
		IProfesorDAO dao= new ProfesorDaoImp();
		dao.listarResultados(ListProf);
	}
	
	public boolean actualizar(Profesor prof) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.actualizar(prof);
	}
	
	public boolean eliminar(int id) {
		IProfesorDAO dao= new ProfesorDaoImp();
		return dao.eliminar(id);
	}
}
