import fundamentos.*;

public class Fundamentos {

	    public static void main (String[] args) {

	        Menu menu= new Menu("Prueba de Menu");
	        int op;

	        menu.insertaOpcion("Insertar libro",1);
	        menu.insertaOpcion("Borrar libro",2);
	        menu.insertaOpcion("Prestar libro",3);
	        menu.insertaOpcion("Modificar libro",4);
	        menu.insertaOpcion("Salir",5);
	        do {
	           op=menu.leeOpcion("Elige una opcion");

	           Mensaje men = new Mensaje();
	           men.escribe("La opcion leida es "+op);
	        } while (op!=5);
	        menu.cierra();
	        System.exit(0);
	    }

}
