import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class DiaSemana {

	public static String diaSemana (int dia, int mes, int ano)
    {
        String letraD="";
        /*Calendar c = Calendar.getInstance();
        c.set(ano, mes, dia, 0, 0, 0);
        nD=c.get(Calendar.DAY_OF_WEEK);*/
        TimeZone timezone = TimeZone.getDefault();
        Calendar calendar = new GregorianCalendar(timezone);
        calendar.set(ano, mes-1, dia);
        int nD=calendar.get(Calendar.DAY_OF_WEEK);
        //Log.i("result","diaSemana: "+nD+" dia:"+dia+" mes:"+mes+ "a�o:" +ano);
        switch (nD){
            case 1: letraD = "Domingo";
                break;
            case 2: letraD = "Lunes";
                break;
            case 3: letraD = "Martes";
                break;
            case 4: letraD = "Mi�rcoles";
                break;
            case 5: letraD = "Jueves";
                break;
            case 6: letraD = "Viernes";
                break;
            case 7: letraD = "S�bado";
                break;
        }

        return letraD;
    }
	
	public static void main(String[] args) {
		int dia = 13;
		int mes = 12;
		int anio = 2019;
		System.out.println("El d�a " + dia +  "/" + mes + "/" + anio + " fue " + diaSemana (dia, mes, anio));

	}

}
