
public class EjemplosIfs {

	public static void main(String[] args) {

		System.out.println("valorAbsoluto:            " + LibIfs.valorAbsoluto(-4));
		System.out.println("max2 (int):               " + LibIfs.max2(4, 2));
		System.out.println("max2 (double):	          " + LibIfs.max2(3.5, 3.4));
		System.out.println("max3Heavy:	              " + LibIfs.max3Heavy(2, 4, 5));
		System.out.println("max3Fino:	              " + LibIfs.max3Fino(6, 3, 5));
		System.out.println("max3Cool:	              " + LibIfs.max3Cool(5, 2, 3));
		System.out.println("anillosDigito:	          " + LibIfs.anillosDigito(3));
		System.out.println("anillosDigitoSwitch:	  " + LibIfs.anillosDigitoSwitch(3));
		System.out.println("numSolucionesPolinomio:	  " + LibIfs.numSolucionesPolinomio(3, 4, 5));
		System.out.println("queCuadrante:	          " + LibIfs.queCuadrante(4.7, 3.1));
		System.out.println("parteEntera:	          " + LibIfs.parteEntera(3.5));
	}

}
