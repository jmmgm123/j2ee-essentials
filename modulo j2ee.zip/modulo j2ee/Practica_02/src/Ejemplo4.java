/*
 * Funciones
 * */

public class Ejemplo4 {

	static double base = 2.3;
	static double altura = 6.0;

	public static double areaTriangulo(double base, double altura){
		return (base * altura)/2;
	}

	public static int getDigito(int cifra, int pos){
		return (cifra/(int)Math.pow(10,pos-1)) % 10;
	}


	public static double sumaVectores(double m1, double m2, double angulo){
		return Math.sqrt(m1*m1 + m2*m2 + 2*m1*m2*Math.cos (angulo));
	}

	public static int enesimo(int primero, int razon, int n){
		return primero + (n - 1) * razon;
	}

	public static int sumaNprimeros(int primero, int razon, int n){
		return ((primero + enesimo(primero, razon, n)) * n) / 2;
	}

	public static void main(String[] args) {

		double base2 = 10;
		double altura2 = 5.5;

		double areaTriangulo = 0.5 * base * altura;
		double prueba12 = areaTriangulo;

		System.out.println("areaTriangulo (variable)... "  + prueba12);
		System.out.println("areaTriangulo (funci�n)... "  + areaTriangulo(base, altura));
		System.out.println("areaTriangulo (funci�n)... "  + areaTriangulo(base2, altura2));
		System.out.println("areaTriangulo (funci�n)... "  + areaTriangulo(base2, altura));
		System.out.println("areaTriangulo (funci�n)... "  + areaTriangulo(base, altura2));

		int cifra = 1234;
		int posicion =  3;

		System.out.println("la posici�n " + posicion + " de la cifra " + cifra +  " es: "  + getDigito(cifra,posicion));


		double m1 = 6;
		double m2 = 5;
		// 24�39' en decimal es 24,65
		double angulo = 24.65;

		System.out.println("sumaVectores " + sumaVectores(m1, m2, angulo));


		int primero = 4;
		int razon = 7;
		int n = 4;

		System.out.println("sumaNprimeros " + sumaNprimeros(primero, razon, n));

		System.out.println("Le estamos pasando " + args.length + " par�metro/s");
		System.out.println("Par�metro 0 - " + args[0]);
		System.out.println("Par�metro 1 - " + args[1]);		

		


	}//main

}//Ejemplo4


