
public class Expresiones {

	public static void main(String[] args) {
	
		System.out.println("1 - Area c�rculo: " + MiLibreria.areaCirculo(10));
		System.out.println("2 - �rea corona: " + MiLibreria.corona(10, 20));
		System.out.println("3 - Volumen cilindro: " + MiLibreria.volumenCilindro(10, 20));
		System.out.println("4 - Volumen arandela: " + MiLibreria.volumenArandela(20, 10, 10));
		System.out.println("5 - masa arandela: " + MiLibreria.masaArandela(20, 10, 10, 10) + " gr");
		System.out.println("6 - fuerza atracci�n: " + MiLibreria.fuerzaAtraccionPrefija(6.67428e-11, 1000, 1000, 200));
		System.out.println("7 - Distancia entre dos puntos: " + MiLibreria.distancia(1, 2, 3, 4));
	
		double angulo = 10;
		System.out.println("8 - �ngulo en radianes: " + angulo + " son  " + MiLibreria.gradosASexagesimales(angulo) + " sexagesimales");

		System.out.println("9 - Signo de la cifra: " + MiLibreria.signoNumero(-10));
		System.out.println("10 - Parte entera: " + MiLibreria.parteEntera(23.44));
		
		double euros = 12;
		double dolares = 15;
		double cambio = 1.32123;
		System.out.println("11 - " + euros + " euros son " + MiLibreria.cambioDolares(euros, cambio) + " d�lares (Cambio " + cambio + ")");
		System.out.println("11 - " + dolares + " dolares son " + MiLibreria.cambioEuros(dolares, cambio) + " euros (Cambio " + cambio + ")");
		 
		double grados = 12.5;
		double farenheit = 54.5;
		System.out.println("12 - " +  grados + " �C son " + MiLibreria.gradosAFarenheit(grados) + " �F");
		System.out.println("12 - " + farenheit + " �F son " + MiLibreria.farenheitAGrados(farenheit)  + " �C");
		
		double precio = 100;
		double descuento = 25;
		System.out.println("13 - el " + descuento + "% de " + precio + " es " + MiLibreria.descuento(precio, descuento));
		
		int horas = 18;
		System.out.println("15 - " + horas + " son " + MiLibreria.getHora(horas));
		
			
		
	}

}


