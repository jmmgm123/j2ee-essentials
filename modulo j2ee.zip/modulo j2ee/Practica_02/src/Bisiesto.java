
public class Bisiesto {
	
	public static boolean esBisiesto(int year) {
		return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
	}	
	
	public static void main(String args[]){
		int year;
		//boolean bisiesto;
		
		year = Integer.parseInt(args[0]);
		
		//bisiesto = ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
		
		String mensaje = "el a�o " + args[0];
		
		
		if(esBisiesto(year)){
			mensaje = mensaje + " es bisiesto";
		} else {
			mensaje = mensaje + " no es bisiesto";
		}
		
		System.out.println(mensaje);
			
	}

}//Bisiesto
