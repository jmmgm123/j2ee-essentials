
public class MiLibreria {

	//Ejercicio 1: Calcular el �rea de un c�rculo.
	public static double areaCirculo(double radio) {
		return Math.PI * Math.pow(radio, 2);
	}
	
	//Ejercicio 2: Calcular el �rea de una corona circular.
	public static double corona(double radio1, double radio2) {
		return areaCirculo(radio1) - areaCirculo(radio2); 
	}
	
	//Ejercicio 3: Calcular el volumen de un cilindro. Recibe el radio del c�rculo que forma
	//su base y su altura y calcula el volumen del cilindro.
	public static double volumenCilindro(double radio, double altura) {
		return Math.PI * Math.pow(radio, 2) * altura;
	}
	
	//Ejercicio 4: Calcular el volumen de una arandela (corona circular con altura).
	public static double volumenArandela(double radio1, double radio2, double altura) {
		return (volumenCilindro(radio1, altura) - volumenCilindro(radio2, altura))*altura;
	}
	
	//Ejercicio 5: Dada la densidad de una arandela (en gr/cm3), calcular su masa (en gr).
	public static double masaArandela(double radio1, double radio2, double altura, double densidad) {
		return volumenArandela(radio1, radio2, altura) * densidad;
	}
	
	//Ejercicio 6: Calcular la fuerza de atracci�n entre dos masas. Escribir la expresi�n en
	//prefija y en infija.
	public static double fuerzaAtraccionPrefija(double G, double masa1, double masa2, double distancia) {
		return (G * masa1 * masa2) / (distancia * distancia);
	}
	
	//Ejercicio 7: Calcular la distancia entre dos puntos del plano.
	public static double distancia(double x1, double y1, double x2, double y2){
		return Math.hypot(x2-x1, y2-y1);
	}
	
	// Ejercicio 8: Dada una medida de �ngulo en radianes, calcular su equivalente en
	// grados sexagesimales.
	public static double gradosASexagesimales(double angulo) {
        return angulo* 180 / Math.PI;
	}
	
	
	//Ejercicio 9: Calcular el signo de un n�mero. El resultado debe ser 1 en caso de que
	//sea positivo y -1 en caso de que sea negativo. Pauta: Utilizar el valor absoluto.
	public static int signoNumero(int cifra) {
		return cifra / Math.abs(cifra) ;
	}
	
	//Ejercicio 10: Calcular la parte entera de un n�mero real.
	public static int parteEntera(double numero) {
		double num = numero - (numero % 1);
		return (int)num;
		//return   (int) numero - (int)(numero % 1);
	}
	
	// Ejercicio 11: Convertir una cantidad de dinero en euros a su equivalente en d�lares
	// y viceversa. Consultar un conversor en Internet para obtener las tasas de cambio y
	// para preparar los ejemplos.
	public static double cambioDolares(double euros, double cambio) {
		return euros * cambio;
	}
	
	public static double cambioEuros(double dolares, double cambio) {
		return dolares * cambio;
	}
	
	// Ejercicio 12: Convertir medidas de temperatura en grados Celsius a grados
	// Fahrenheit y al rev�s.
	public static double gradosAFarenheit(double grados) {
		 return (grados * 1.8) + 32 ;
	}
	
	public static double farenheitAGrados(double farenheit) {
		 return (farenheit - 32) / 1.8 ;
	}	
	
	// Ejercicio 13: Calcular el precio resultante que queda al aplicar sobre un precio en
	// euros un descuento en forma de porcentaje.
	public static double descuento(double precio, double descuento){
		return precio - ((precio * descuento) / 100);
	} 
	
	// Ejercicio 14: Dadas dos magnitudes M1 y M2, con M2 <= M1, calcular el porcentaje
	// de ahorro que supone M2 sobre M1.
	
	
	// Ejercicio 15: Calcular en qu� n�mero estar� la manecilla peque�a de un reloj
	// anal�gico si, empezando en el 12, han transcurrido H horas.
	public static int getHora(int horas) {
		return (12 + horas )  % 12;
	}
	
	//Ejercicio 16: Calcular: a) el d�gito menos significativo de un n�mero entero; b) el
	//n�mero que queda al quitar el d�gito menos significativo a un n�mero; c) el n�mero
	//que queda al quitar los I d�gitos menos significativos a un n�mero; d) el digito que
	//ocupa la posici�n I en un n�mero entero.
	
}//MiLibreria
