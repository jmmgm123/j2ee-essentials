
public class MainPrueba {

	/*********************************
	* Ejercicio1
	* ********************************/
	public static boolean tieneFormatoNif(char[] nif) {
		return nif.length==9 && esNumeroCorrecto(nif) && esLetraMayuscula(nif[8]); 
	}
	
	
	public static boolean esNumeroCorrecto(char [] nif) {
		boolean todoDig = true;
		int i = 0;
		while(i < nif.length-1 && todoDig) {
			if(!esDigito(nif[i])) {
				todoDig = false;
			} else {
				i++;
			}
		}
		return todoDig;
	}

	public static boolean esLetraMayuscula(char c) {
		return 'A'<=c && c<='Z' && c!='�';
	} 
	
	public static boolean esDigito(char c) {
		return '0'<=c && c<='9';
	}
	
	/*********************************
	* Ejercicio2
	* ********************************/
	
	public static int aNum(char[] nif) {
		return aNumero(sacarDigito(nif));
	}
	
	public static int aNumero(int[] col) {
		int suma = 0;
		for(int i = 0; i<col.length; i++) {
			suma+= col[i]*Math.pow(10, col.length-i-1);
		}
		return suma;
	}
	
	public static int[] sacarDigito(char[] nif) {
		int[] solucion = new int[nif.length-1];
		for(int i=0; i<nif.length-1;i++) {
			solucion[i] = aDigito(nif[i]);
		} 
		return solucion;
	}
	
	public static int aDigito(char c) {
		return c - '0';
	}
	//fin ejercicio2
	
	public static void main(String[] args) {

		char[] nif1 = {'0', '3', '4', '4', '5', '0', '8','5','Z'};
		char[] nif2 = {'0', '3', '4', '4', '5', '0', '8','5','�'};
		char[] nif3 = {'0', '3', '4', 'P', '5', '0', '8','5','Z'};
		char[] nif4 = {'0', '3', '4', '0', '5','R'};
		
		System.out.println("Soluci�n Ejercicio1");
		System.out.println(tieneFormatoNif(nif1));
		System.out.println(tieneFormatoNif(nif2));
		System.out.println(tieneFormatoNif(nif3));
		System.out.println(tieneFormatoNif(nif4));
		
		System.out.println("");
		
		char[] nif5 = {'0', '0', '0', '2', '4','R'};
		char[] nif6 = {'1', '2', '0', '4', 'P'};
		char[] nif7 = {'1', '2', '0', '4', '4','1','P'};
		
		System.out.println("Soluci�n Ejercicio2");
		System.out.println(aNum(nif5));
		System.out.println(aNum(nif6));
		System.out.println(aNum(nif7));
	
	}

}
