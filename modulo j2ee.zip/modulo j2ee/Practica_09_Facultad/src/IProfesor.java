
public interface IProfesor extends IPersona, IEmpleado, IDepartamento {

}
