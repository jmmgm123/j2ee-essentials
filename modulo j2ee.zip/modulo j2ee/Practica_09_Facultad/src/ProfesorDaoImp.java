import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProfesorDaoImp implements IProfesorDAO {

	@Override
	public boolean registrar(IProfesor prof) {
		boolean registrar = false;

		BD bd = new BD();

		String sql = "INSERT INTO `profesor`(`nombre`, `apellido1`, `apellido2`, `dni`, `estadoCivil`, `a�oImcorporacion`, `nDespacho`, `departamento`) VALUES ('"
				+ prof.getNombre() + "','" + prof.getApellido1() + "','" + prof.getApellido2() + "','" + prof.getDni()
				+ "','" + prof.getEstadoCivil() + "','" + prof.getA�oIncorporacion() + "','" + prof.getNumDespacho()
				+ "','" + prof.getNombreDep() + "')";

		try {
			if (bd.doUpdate(sql) > 0) {
				registrar = true;
			} else {
				registrar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo registrar");
			registrar = false;
			e.printStackTrace();
		}
		return registrar;
	}

	@Override
	public List<IProfesor> obtener() {

		BD bd = new BD();

		String sql = "SELECT * FROM `profesor`";

		List<IProfesor> listaProfesor = new ArrayList<IProfesor>();
		int i = 0;
		try {
			ResultSet rs = bd.doQuery(sql);
			while (rs.next()) {
				Profesor prof = new Profesor();
				prof.setNombre(rs.getString(1));
				prof.setApellido1(rs.getString(2));
				prof.setApellido2(rs.getString(3));
				prof.setDni(rs.getString(4));
				prof.setEstadoCivil(rs.getString(5));
				prof.setA�oIncorporacion(new Fecha(rs.getString(6)));
				prof.setNumDespacho(rs.getString(7));
				prof.setNombreDep(rs.getString(8));
				listaProfesor.add(prof);
			}
			bd.finish();
		} catch (SQLException e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo obtener");
			e.printStackTrace();
		}

		return listaProfesor;
	}

	public void listarResultados(List<IProfesor> ListProf) {
		Iterator iter = ListProf.iterator();
		while (iter.hasNext())
			System.out.println(iter.next());
	}

	@Override
	public boolean actualizar(IProfesor prof) {

		BD bd = new BD();

		boolean actualizar = false;

		String sql = "UPDATE `profesor` SET " + "nombre='" + prof.getNombre() + "', apellido1='" + prof.getApellido1()
				+ "', apellido2='" + prof.getApellido2() +
				// "', dni='"+prof.getDni()+
				"', estadoCivil='" + prof.getEstadoCivil() + "', a�oImcorporacion='" + prof.getA�oIncorporacion()
				+ "', nDespacho='" + prof.getNumDespacho() + "', departamento='" + prof.getNombreDep() +

				"'" + " WHERE dni='" + prof.getDni() + "'";

		try {
			if (bd.doUpdate(sql) > 0) {
				actualizar = true;
			} else {
				actualizar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase ClienteDaoImple, m�todo actualizar");
			e.printStackTrace();
			actualizar = false;
		}
		return actualizar;
	}

	@Override
	public boolean eliminar(IProfesor prof) {
		
		BD bd = new BD();

		boolean eliminar = false;

		String sql = "DELETE FROM `profesor` WHERE dni='" + prof.getDni()+"'";
		try {
			if (bd.doUpdate(sql)>0)
				eliminar = true;
			else 
				eliminar = false;
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase ProfesorDaoImpl, m�todo eliminar");
			e.printStackTrace();
		}
		return eliminar;
	}

}
