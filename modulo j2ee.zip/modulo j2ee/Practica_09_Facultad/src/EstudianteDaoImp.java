import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EstudianteDaoImp implements IEstudianteDAO {

	@Override
	public boolean registrar(Estudiante est) {
		boolean registrar = false;

		BD bd = new BD();

		String sql = "INSERT INTO `estudiante`(`nombre`, `apellido1`, `apellido2`, `dni`, `estadoCivil`, `curso`) VALUES ('"
				+ est.getNombre() + "','" + est.getApellido1() + "','" + est.getApellido2() + "','" + est.getDni()
				+ "','" + est.getEstadoCivil() + "','" + est.getNombreCurso() + "')";

		try {
			if (bd.doUpdate(sql) > 0) {
				registrar = true;
			} else {
				registrar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase EstudianteDaoImpl, m�todo registrar");
			registrar = false;
			e.printStackTrace();
		}
		return registrar;
	}

	@Override
	public List<Estudiante> obtener() {

		BD bd = new BD();

		String sql = "SELECT * FROM `estudiante`";

		List<Estudiante> listaEstudiante = new ArrayList<Estudiante>();
		int i = 0;
		try {
			ResultSet rs = bd.doQuery(sql);
			while (rs.next()) {
				Estudiante est = new Estudiante();
				est.setId(rs.getInt(1));
				est.setNombre(rs.getString(2));
				est.setApellido1(rs.getString(3));
				est.setApellido2(rs.getString(4));
				est.setDni(rs.getString(5));
				est.setEstadoCivil(rs.getString(6));
				est.setNombreCurso(rs.getString(7));
				listaEstudiante.add(est);
			}
			bd.finish();
		} catch (SQLException e) {
			System.out.println("Error: Clase EstudianteDaoImpl, m�todo obtener");
			e.printStackTrace();
		}

		return listaEstudiante;
	}

	public void listarResultados(List<Estudiante> ListEst) {
		Iterator iter = ListEst.iterator();
		while (iter.hasNext())
			System.out.println(iter.next());
	}

	@Override
	public boolean actualizar(Estudiante est) {

		BD bd = new BD();

		boolean actualizar = false;

		String sql = "UPDATE `profesor` SET " + "nombre='" + est.getNombre() + "', apellido1='" + est.getApellido1()
				+ "', apellido2='" + est.getApellido2() +
				// "', dni='"+prof.getDni()+
				"', estadoCivil='" + est.getEstadoCivil() + "', curso='" + est.getNombreCurso() +
				"'" + " WHERE id='" + est.getId() + "'";

		try {
			if (bd.doUpdate(sql) > 0) {
				actualizar = true;
			} else {
				actualizar = false;
			}
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase EstudianteDaoImple, m�todo actualizar");
			e.printStackTrace();
			actualizar = false;
		}
		return actualizar;
	}

	@Override
	public boolean eliminar(int id) {
		
		BD bd = new BD();

		boolean eliminar = false;

		String sql = "DELETE FROM `profesor` WHERE id='" + id;
		try {
			if (bd.doUpdate(sql)>0)
				eliminar = true;
			else 
				eliminar = false;
			bd.finish();
		} catch (Exception e) {
			System.out.println("Error: Clase EstudianteDaoImpl, m�todo eliminar");
			e.printStackTrace();
		}
		return eliminar;
	}

}
