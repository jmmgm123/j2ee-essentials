import java.util.List;

public interface IEstudianteDAO {
	public boolean registrar(Estudiante estudiante);
	public List<Estudiante> obtener();
	public boolean actualizar(Estudiante estudiante);
	public boolean eliminar(int id);
	public void listarResultados(List<Estudiante> ListEstudiante);
}
