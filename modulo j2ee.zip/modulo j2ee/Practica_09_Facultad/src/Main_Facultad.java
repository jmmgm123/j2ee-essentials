import java.util.Iterator;

public class Main_Facultad {

	public static void main(String[] args) {

		Departamento[] departamentos = new Departamento[3]; 
		departamentos[0] = new Departamento("Historia");
		departamentos[1] = new Departamento("Inform�tica");
		departamentos[2] = new Departamento("Ingl�s");
		
		Seccion[] secciones = new Seccion[3];
		secciones[0] = new Seccion("Historia");
		secciones[1] = new Seccion("Inform�tica");
		secciones[2] = new Seccion("Ingl�s");
		
		Curso [] cursos = new Curso[3];
		cursos[0] = new Curso("Historia");
		cursos[1] = new Curso("Inform�tica");
		cursos[2] = new Curso("Ingl�s");
		
		
		
		Profesor[] profesores = new Profesor[3];
	
		profesores[0] = new Profesor(
				new Persona("Luis", "Rodriguez", "Albiol", "21544454", "Soltero"),
				new Empleado(new Fecha(12,10,2000), "100"),
				departamentos[1]);
		
		profesores[1] = new Profesor(
				new Persona("Mar�a", "P�rez", "Mayor", "312545", "Soltero"),
				new Empleado(new Fecha(10,2,2012), "200"),
				departamentos[0]);
		
		profesores[2] = new Profesor(
				new Persona("Ana", "P�rez", "Casa", "312", "Casado"),
				new Empleado(new Fecha(15,1,2010), "300"),
				departamentos[2]);
		
		
		for(int i=0; i<profesores.length; i++) {
			System.out.println(profesores[i].toString());
		}
		
System.out.println("");
		
		PersonalServicio[] personalServicio = new PersonalServicio[2];
		
		personalServicio[0] = new PersonalServicio(
				new Persona("Manuel", "Martinez", "Albiol", "216545", "Casado"),
				new Empleado(new Fecha(12,10,2000), "101"),
				secciones[1]);
		
		personalServicio[1] = new PersonalServicio(
				new Persona("Ana", "Le�n", "Casa", "234234", "Soltero"),
				new Empleado(new Fecha(15,1,2010), "202"),
				secciones[0]);
		
		for(int i=0; i<personalServicio.length; i++) {
			System.out.println(personalServicio[i].toString());
		}
		
System.out.println("");
		
		Estudiante[] estudiantes = new Estudiante[2];
		
		estudiantes[0] = new Estudiante(
				new Persona("Alfonso", "Medina", "Casas", "216545L", "soltero"),
				cursos[1]);
		
		estudiantes[1] = new Estudiante(
				new Persona("Mar�a", "Gonzalez", "Alberca", "234234G", "soltero"),
				cursos[1]);
		
		for(int i=0; i<estudiantes.length; i++) {
			System.out.println(estudiantes[i].toString());
		}
		
		//BBDD
		try {
			
			ControllerProfesor controllerProf = new ControllerProfesor();
			//System.out.println(controllerProf.registrar(profesores[2]));
			
			controllerProf.listarResultados(controllerProf.obtener());
			
			//System.out.println(controllerProf.actualizar(profesores[1]));
			
			//System.out.println(controllerProf.eliminar(profesores[1]));
			
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

	}

}
