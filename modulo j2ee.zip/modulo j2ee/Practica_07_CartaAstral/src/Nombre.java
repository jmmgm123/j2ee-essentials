
public class Nombre {
	
	private String nombre;
	private String apellido1;
	private String apellido2;
	
	
	public Nombre() {}
	
	public Nombre(String nomb, String ape1, String ape2) {
		apellido1 = ape1;
		apellido2 = ape2;
		nombre = nomb;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nom) {
		nombre = nom;
	}

	public String getApellido1() {
		return apellido1;
	}
	
	public void setApellido1(String ape1) {
		apellido1 = ape1;
	}
	
	public String getApellido2() {
		return apellido2;
	}
	
	public void setApellido2(String ape2) {
		apellido2 = ape2;
	}
	
	public String aTexto() {
		return nombre + " " + apellido1 + " " + apellido2;
	}
	
}

