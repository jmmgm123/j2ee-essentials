
public class Contacto {
	
	private Email email;
	private Telefono telf;
	
	
	public Contacto() 
	{
		email = new Email();
		telf = new Telefono();
	}
	
	/**
	 * @param email
	 * @param telf
	 */
	public Contacto(Email email, Telefono telf) {
		super();
		this.email = email;
		this.telf = telf;
	}

	public Email getEmail() {
		return email;
	}
	
	public void setEmail(Email email) {
		this.email = email;
	}
	
	public Telefono getTelf() {
		return telf;
	}
	
	public void setTelf(Telefono telf) {
		this.telf = telf;
	}

	public String aTexto() {
		return "email=" + email.aTexto() + ", telf=" + telf.aTexto();
	}
	
	
	
}
