
public class Telefono {

	private int numTelefono;
	private String prefTelefono;
	private String tipoTelefono;
	
	
	public Telefono() {
		this.numTelefono = 0;
		this.prefTelefono = "";
		this.tipoTelefono = "";
	}
	
	/**
	 * @param numTelefono
	 * @param prefTelefono
	 */
	public Telefono(String prefTelefono, int numTelefono, String tipoTelefono) {
		this.numTelefono = numTelefono;
		this.prefTelefono = prefTelefono;
		this.tipoTelefono = tipoTelefono;
	}

	public int getNumTelefono() {
		return numTelefono;
	}

	public void setNumTelefono(int numTelefono) {
		this.numTelefono = numTelefono;
	}

	public String getPrefTelefono() {
		return prefTelefono;
	}

	public void setPrefTelefono(String prefTelefono) {
		this.prefTelefono = prefTelefono;
	}
	
	public String getTipoTelefono() {
		return tipoTelefono;
	}

	public void setTipoTelefono(String tipoTelefono) {
		this.tipoTelefono = tipoTelefono;
	}

	public String aTexto() {
		
		String tel = "vacio";
		if(!this.tipoTelefono.equals("") && !this.prefTelefono.equals("") && this.numTelefono != 0) {
			tel = tipoTelefono + "/" + prefTelefono + "-" + numTelefono;
		}
		return tel;

	}
	
}
