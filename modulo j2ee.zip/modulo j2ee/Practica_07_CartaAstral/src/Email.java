
public class Email {

	private String nombreEmail;
	private String dominioEmail;
	private String extesionEmail;
	
	
	public Email() {
		this.nombreEmail = "";
		this.dominioEmail = "";
		this.extesionEmail = "";
	}

	
	/**
	 * @param nombreEmail
	 * @param dominioEmail
	 */
	public Email(String email) {
		this.nombreEmail = getNombreEmailFromEmail(email);
		this.dominioEmail = getDominioEmailFromEmail(email);
		this.extesionEmail = getExtensionEmailFromEmail(email);
	}

	public String getNombreEmail() {
		return nombreEmail;
	}

	public void setNombreEmail(String nombreEmail) {
		this.nombreEmail = nombreEmail;
	}

	public String getDominioEmail() {
		return dominioEmail;
	}

	public void setDominioEmail(String dominioEmail) {
		this.dominioEmail = dominioEmail;
	}


	public String aTexto() {
		String correo = "vacio";
		if(!this.nombreEmail.equals("") && !this.dominioEmail.equals("") && !this.extesionEmail.equals("")) {
			correo = nombreEmail + "@" + dominioEmail + "." + extesionEmail;
		}
		return correo;
	}
	
	private String getNombreEmailFromEmail(String email) {
		return email.substring(0, email.indexOf("@"));
	}
	
	private String getDominioEmailFromEmail(String email) {
		return email.substring(email.indexOf("@")+1, email.indexOf("."));
	}
	
	private String getExtensionEmailFromEmail(String email) {
		return email.substring(email.indexOf(".")+ 1, email.length());
	}


	
	
}
