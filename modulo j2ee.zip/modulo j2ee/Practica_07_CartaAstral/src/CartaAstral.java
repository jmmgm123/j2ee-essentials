

public class CartaAstral {

	//es com�n y compartido por todos
	private static int ultimoId = 0;
	
	private int id = 0;
	private Nombre nombre;
	private Fecha fechaNacimiento;
	private Horario horaNacimiento;
	private Contacto contacto;
	private String horoscopo;
	
		
	public CartaAstral(){}

	/**
	 * @param nombre
	 * @param fechaNacimiento
	 * @param horaNacimiento
	 * @param contacto
	 */
	public CartaAstral(Nombre nombre, Fecha fechaNacimiento, Horario horaNacimiento, Contacto contacto) {
		this.nombre = nombre;
		this.fechaNacimiento = fechaNacimiento;
		this.horaNacimiento = horaNacimiento;
		this.contacto = contacto;
		this.horoscopo = getHoroscopo(fechaNacimiento);
		this.id = this.ultimoId++;
	}

	public Nombre getNombre() {
		return nombre;
	}
	
	public void setNombre(Nombre nombre) {
		this.nombre = nombre;
	}
	
	public Fecha getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public void setFechaNacimiento(Fecha fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public Horario getHoraNacimiento() {
		return horaNacimiento;
	}
	
	public void setHoraNacimiento(Horario horaNacimiento) {
		this.horaNacimiento = horaNacimiento;
	}

	
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	public String aTexto() {
		return "CartaAstral [ \n id =" + id + ", \n Nombre = " + nombre.aTexto() + ", \n Fecha nacimiento = " + fechaNacimiento.aTexto() + ", \n Hora nacimiento = "
				+ horaNacimiento.aTexto() + ", \n Contacto = [" + contacto.aTexto() + "], \n Horoscopo =  " + horoscopo  + "  \n]";
	}
	
	private String getHoroscopo(Fecha f) {
		String horoscopo = "";
		int mes = f.getMes();
		int dia = f.getDia();

		switch(mes) {		
		case 1: 
			// Enero
			if (dia>=21)
				horoscopo = "Acuario";
			else
				horoscopo = "Capricornio";				
			break;
		case 2:
			// Febrero
			if (dia>=20)
				horoscopo = "Piscis";
			else
				horoscopo = "Acuario";
			break;
		case 3:
			// Marzo
			if (dia>=21)
				horoscopo = "Aries";
			else
				horoscopo = "Piscis";
			break;

		case 4:
			// Abril
			if (dia>=21)
				horoscopo = "Tauro";
			else
				horoscopo = "Aries";
			break;

		case 5:
			// Mayo
			if (dia>=22)
				horoscopo = "G�minis";
			else
				horoscopo = "Tauro";
			break;

		case 6:
			// Junio
			if (dia>=22)
				horoscopo = "C�ncer";
			else
				horoscopo = "G�minis";
			break;

		case 7:
			// Julio
			if (dia>=24)
				horoscopo = "Leo";
			else
				horoscopo = "C�ncer";
			break;

		case 8:
			// Agosto
			if (dia>=24)
				horoscopo = "Virgo";
			else
				horoscopo = "Leo";
			break;

		case 9:
			// Septiembre
			if (dia>=24)
				horoscopo = "Libra";
			else
				horoscopo = "Virgo";
			break;

		case 10:
			// Octubre
			if (dia>=24)
				horoscopo = "Escorpio";
			else
				horoscopo = "Libra";
			break;

		case 11:
			// Noviembre
			if (dia>=23)
				horoscopo = "Sagitario";
			else
				horoscopo = "Escorpio";
			break;

		case 12:
			// Diciembre
			if (dia>=22)
				horoscopo = "Capricornio";
			else
				horoscopo = "Sagitario";
			break;
		}
		
		return horoscopo;
	}
	
	private static int generaId() {
		return 2;
	}

}
