
public class MainCartaAstral {

	public static void main(String[] args) {
		
		CartaAstral ca1 = new CartaAstral(
				new Nombre("Juan", "Martinez", "Falomir"),
				new Fecha(21,1,2011),
				new Horario(13,51,12),
				new Contacto(
						new Email("juan_martinezF@gmail.com"),
						new Telefono("+34", 686954821, "movil")
						)
				);

		CartaAstral ca2 = new CartaAstral(
				new Nombre("Luis", "Gutierrez", "Lorente"),
				new Fecha(21,2,2012),
				new Horario(13,51,12),
				new Contacto(
						new Email("luis_gutierrez@gmail.com"),
						new Telefono("+34", 686954831, "movil")
						)
				);
		
		CartaAstral ca3 = new CartaAstral(
				new Nombre("Jose", "Casta�o", "Falomir"),
				new Fecha(21,12,2012),
				new Horario(13,51,12),
				new Contacto(
						new Email("jose_casta�o@gmail.com"),
						new Telefono("+34", 686954851, "movil")
						)
				);
		
//		System.out.println(ca1.aTexto());
//		System.out.println(ca2.aTexto());
//		System.out.println(ca3.aTexto());

	}
}
