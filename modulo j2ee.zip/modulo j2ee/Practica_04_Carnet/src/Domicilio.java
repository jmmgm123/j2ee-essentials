
public class Domicilio {
	
	private String tipoVia;
	private String nomVia;
	private String numVia;
	private String pisoVia;
	private String cpVia;
	private String pobVia;
	private String provVia;
	
	public Domicilio(String tipoVia, String nomVia, String numVia, String pisoVia, String cpVia, String pobVia, String provVia) {
		this.tipoVia = tipoVia;
		this.nomVia = nomVia;
		this.numVia = numVia;
		this.pisoVia = pisoVia;
		this.cpVia = cpVia;
		this.pobVia = pobVia;
		this.provVia = provVia;
	}
	
	public String getTipoVia() {
		return this.tipoVia;
	}
	
	public void setTipoVia(String tipoVia) {
		this.tipoVia = tipoVia;
	}
	
	public String getNomVia() {
		return this.nomVia;
	}
	
	public void setNomVia(String nomVia) {
		this.nomVia = nomVia;
	}
	
	public String getNumVia() {
		return this.numVia;
	}
	
	public void setNumVia(String numVia) {
		this.numVia = numVia;
	}
	
	public String getPisoVia() {
		return this.pisoVia;
	}
	
	public void setPisoVia(String pisoVia) {
		this.pisoVia = pisoVia;
	}
	
	public String getCpVia() {
		return this.cpVia;
	}
	
	public void setCpVia(String cpVia) {
		this.cpVia = cpVia;
	}
	
	public String getPobVia() {
		return this.pobVia;
	}
	
	public void setPobVia(String pobVia) {
		this.pobVia = pobVia;
	}
	
	public String getProvVia() {
		return this.provVia;
	}
	
	public void setProvVia(String provVia) {
		this.provVia = provVia;
	}

	public String aTexto() {
		return "tipoVia=" + tipoVia + ", nomVia=" + nomVia + ", numVia=" + numVia + ", pisoVia=" + pisoVia
				+ ", cpVia=" + cpVia + ", pobVia=" + pobVia + ", provVia=" + provVia;
	}
	
	
	
}
