
public class Apellidos {
	
	private  String apellido1;
	private String apellido2;
	
	public Apellidos(String ape1, String ape2) {
		apellido1 = ape1;
		apellido2 = ape2;
	}

	public String getApellido1() {
		return apellido1;
	}
	
	public void setApellido1(String ape1) {
		apellido1 = ape1;
	}
	
	public String getApellido2() {
		return apellido2;
	}
	
	public void setApellido2(String ape2) {
		apellido2 = ape2;
	}
	
	public String aTexto() {
		return apellido1 + " " + apellido2;
	}
	
}

