
public class Carnet {
	
	private String nombre;
	private Apellidos apellidos;
	private String sexo;
	private String nacionalidad;
	private Fecha fechaNacimiento;
	private String numSoporte;
	private Fecha validez;
	private Nif nif;
	private Domicilio domicilio;
	private Progenitores progenitores;
	
	private Anverso anverso;
	private Reverso reverso;
	
	/**
	 * @param nombre
	 * @param apellidos
	 * @param sexo
	 * @param nacionalidad
	 * @param fechaNacimiento
	 * @param numSoporte
	 * @param validez
	 * @param nif
	 * @param domicilio
	 * @param progenitores
	 */
	public Carnet(String nombre, Apellidos apellidos, String sexo, String nacionalidad, Fecha fechaNacimiento,
			String numSoporte, Fecha validez, Nif nif, Domicilio domicilio, Progenitores progenitores) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.sexo = sexo;
		this.nacionalidad = nacionalidad;
		this.fechaNacimiento = fechaNacimiento;
		this.numSoporte = numSoporte;
		this.validez = validez;
		this.nif = nif;
		this.domicilio = domicilio;
		this.progenitores = progenitores;
		
		anverso = new Anverso(nombre, apellidos, sexo, nacionalidad, fechaNacimiento, numSoporte, validez, nif);
		reverso = new Reverso(domicilio, progenitores);
	} 
	
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Apellidos getApellidos() {
		return apellidos;
	}
	
	public void setApellidos(Apellidos apellidos) {
		this.apellidos = apellidos;
	}
	
	public String getSexo() {
		return sexo;
	}
	
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public String getNacionalidad() {
		return nacionalidad;
	}
	
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	
	public Fecha getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public void setFechaNacimiento(Fecha fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public String getNumSoporte() {
		return numSoporte;
	}
	
	public void setNumSoporte(String numSoporte) {
		this.numSoporte = numSoporte;
	}
	
	public Fecha getValidez() {
		return validez;
	}
	
	public void setValidez(Fecha validez) {
		this.validez = validez;
	}
	
	public Nif getNif() {
		return nif;
	}
	
	public void setNif(Nif nif) {
		this.nif = nif;
	}
	
	public Domicilio getDomicilio() {
		return domicilio;
	}
	
	public void setDomicilio(Domicilio domicilio) {
		this.domicilio = domicilio;
	}
	
	public Progenitores getProgenitores() {
		return progenitores;
	}
	
	public void setProgenitores(Progenitores progenitores) {
		this.progenitores = progenitores;
	}

	public Anverso getAnverso() {
		return anverso;
	}


	public void setAnverso(Anverso anverso) {
		this.anverso = anverso;
	}


	public Reverso getReverso() {
		return reverso;
	}


	public void setReverso(Reverso reverso) {
		this.reverso = reverso;
	}


	public String aTexto() {
		return "Carnet: nombre=" + nombre + ", apellidos=[" + apellidos.aTexto() + "], sexo=" + sexo + ", nacionalidad="
				+ nacionalidad + ", fechaNacimiento=" + fechaNacimiento.aTexto() + ", numSoporte=" + numSoporte + ", validez="
				+ validez.aTexto() + ", nif=" + nif.aTexto() + ", domicilio=[" + domicilio.aTexto() + "], progenitores=[" + progenitores.aTexto() + "]";
	}

}
