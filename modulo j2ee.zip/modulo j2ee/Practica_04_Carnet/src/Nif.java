public class Nif {

	private int numeroNif;
	private String letraNif;
	
	public Nif(int num, String letra) {
		
		if(LibNif.validarNif(num + letra)) {
			numeroNif = num;
			letraNif = letra.toUpperCase();
			System.out.println("Nif v�lido");
		} else {
			numeroNif = 0;
			letraNif = "";
			System.out.println("Nif no v�lido");
		}
	}
	
	public Nif(int num) {
		numeroNif = num;
		letraNif = LibNif.calculaLetraNif(num) + "";
	}
	
	public void setNumeroNif(int num) {
		numeroNif = num;
	}
	
	public int getNumeroNif() {
		return numeroNif;
	}
	
	public void setLetraNif(String letra) {
		letraNif = letra.toUpperCase();
	}
	
	public String getLetraNif() {
		return letraNif;
	}

	public String aTexto() {
		return numeroNif + "-" + letraNif;
	}

}
