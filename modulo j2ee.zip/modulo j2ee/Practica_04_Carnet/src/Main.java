
public class Main {

	public static void main(String[] args) {
	
		Apellidos apellidos1 = new Apellidos("Perez", "Castillo");
		System.out.println("Apellidos - " + apellidos1.aTexto());
		
		Nif nif1 = new Nif(123456, "s");
		System.out.println("Nif - " + nif1.aTexto());
		
		Fecha fechaNacimiento1 = new Fecha(12, 10, 1982);
		System.out.println("fechaNacimiento - " + fechaNacimiento1.aTexto());
		
		Fecha validez1 = new Fecha(01, 01, 2025);
		System.out.println("validez - " + validez1.aTexto());
		
		Domicilio domicilio1 = new Domicilio("Calle", "Alberti", "32", "2�", "28005", "Madrid", "Madrid");
		System.out.println("domicilio - " + domicilio1.aTexto());
		
		Progenitores progenitores1 = new Progenitores("Juan", "Mar�a");
		System.out.println("progenitores - " + progenitores1.aTexto());
		
		Carnet carnet1 = new Carnet("Juan", apellidos1, "Masculino", "espa�ola", fechaNacimiento1, "1254147", validez1, nif1, domicilio1, progenitores1);
		
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		carnet1.getApellidos().setApellido1("Perrrez");		
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		carnet1.getDomicilio().setNomVia("Gran V�a");
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		Nif nif2 = new Nif(1, "P");
		
		carnet1.setFechaNacimiento(new Fecha(12, 10, 1999));
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		carnet1.getFechaNacimiento().setMes(11);
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		carnet1.setNif(new Nif(21212));
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		carnet1.setNif(new Nif(212177));
		
		System.out.println("carnet1 - " + carnet1.aTexto());
		
		System.out.println(carnet1.getReverso().aTexto());
		System.out.println(carnet1.getAnverso().aTexto());
		
	}

}


