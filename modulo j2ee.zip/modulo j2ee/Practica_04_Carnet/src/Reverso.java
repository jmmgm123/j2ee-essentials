
public class Reverso {

	private Domicilio domicilio;
	private Progenitores progenitores;
	

	/**
	 * @param domicilio
	 * @param progenitores
	 */
	public Reverso(Domicilio domicilio, Progenitores progenitores) {
		this.domicilio = domicilio;
		this.progenitores = progenitores;
	}

	
	public Domicilio getDomicilio() {
		return domicilio;
	}
	
	public void setDomicilio(Domicilio domicilio) {
		this.domicilio = domicilio;
	}
	
	public Progenitores getProgenitores() {
		return progenitores;
	}
	
	public void setProgenitores(Progenitores progenitores) {
		this.progenitores = progenitores;
	}

	public String aTexto() {
		return "Reverso: domicilio=[" + domicilio.aTexto() + "], progenitores=[" + progenitores.aTexto() + "]";
	}

	
}
