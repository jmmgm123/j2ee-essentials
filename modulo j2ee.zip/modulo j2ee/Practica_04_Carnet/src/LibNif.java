import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LibNif {
	
	private static String letrasNif="TRWAGMYFPDXBNJZSQVHLCKE";
	
	public static boolean validarNif(String nif){
        boolean correcto=false;
        Pattern pattern=Pattern.compile("(\\d{1,8})([TRWAGMYFPDXBNJZSQVHLCKEtrwagmyfpdxbnjzsqvhlcke])");
        Matcher matcher=pattern.matcher(nif);
        if(matcher.matches()){
            String letra=matcher.group(2);
            int index=Integer.parseInt(matcher.group(1));
            index=index%23;
            String reference=letrasNif.substring(index,index+1);
            if(reference.equalsIgnoreCase(letra)){
                correcto=true;
            }else{
                correcto=false;
            }
        }else{
            correcto=false;
        }
        return correcto;
    }
	
	
	public static char calculaLetraNif(int numNif) {
	    return  letrasNif.charAt(numNif % 23);
    } 
}
