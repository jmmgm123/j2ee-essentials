
public class Progenitores {

	private String nombPadre;
	private String nomMadre;
	
	/**
	 * @param nombPadre
	 * @param nomMadre
	 */
	public Progenitores(String nombPadre, String nomMadre) {
		this.nombPadre = nombPadre;
		this.nomMadre = nomMadre;
	}

	public String getNombPadre() {
		return nombPadre;
	}

	public void setNombPadre(String nombPadre) {
		this.nombPadre = nombPadre;
	}

	public String getNomMadre() {
		return nomMadre;
	}

	public void setNomMadre(String nomMadre) {
		this.nomMadre = nomMadre;
	}


	public String aTexto() {
		return "nombPadre=" + nombPadre + ", nomMadre=" + nomMadre;
	}
	
	
}
