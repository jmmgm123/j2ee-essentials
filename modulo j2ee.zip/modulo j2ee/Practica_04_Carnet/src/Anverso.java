
public class Anverso {

	private String nombre;
	private Apellidos apellidos;
	private String sexo;
	private String nacionalidad;
	private Fecha fechaNacimiento;
	private String numSoporte;
	private Fecha validez;
	private Nif nif;
	
	/**
	 * @param nombre
	 * @param apellidos
	 * @param sexo
	 * @param nacionalidad
	 * @param fechaNacimiento
	 * @param numSoporte
	 * @param validez
	 * @param nif
	 */
	public Anverso(String nombre, Apellidos apellidos, String sexo, String nacionalidad, Fecha fechaNacimiento,
			String numSoporte, Fecha validez, Nif nif) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.sexo = sexo;
		this.nacionalidad = nacionalidad;
		this.fechaNacimiento = fechaNacimiento;
		this.numSoporte = numSoporte;
		this.validez = validez;
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Apellidos getApellidos() {
		return apellidos;
	}
	
	public void setApellidos(Apellidos apellidos) {
		this.apellidos = apellidos;
	}
	
	public String getSexo() {
		return sexo;
	}
	
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public String getNacionalidad() {
		return nacionalidad;
	}
	
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	
	public Fecha getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public void setFechaNacimiento(Fecha fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public String getNumSoporte() {
		return numSoporte;
	}
	
	public void setNumSoporte(String numSoporte) {
		this.numSoporte = numSoporte;
	}
	
	public Fecha getValidez() {
		return validez;
	}
	
	public void setValidez(Fecha validez) {
		this.validez = validez;
	}
	
	public Nif getNif() {
		return nif;
	}
	
	public void setNif(Nif nif) {
		this.nif = nif;
	}


	public String aTexto() {
		return "Anverso: nombre=" + nombre + ", apellidos=[" + apellidos.aTexto() + "], sexo=" + sexo + ", nacionalidad="
				+ nacionalidad + ", fechaNacimiento=" + fechaNacimiento.aTexto() + ", numSoporte=" + numSoporte + ", validez="
				+ validez.aTexto() + ", nif=" + nif.aTexto();
	}

}
