
public class mainBucles {

	public static void main(String[] args) {
		int num = 515103455;
		System.out.println("Para el n�mero " + num + ":");
		System.out.println(" - esPar:  " + Bucles_1.esPar(num));
		System.out.println(" - sumaCifras: " + Bucles_1.sumaCifras(num));
		System.out.println(" - sumaCifrasPares: " + Bucles_1.sumaCifrasPares(num));
		System.out.println(" - sumaCifrasPosPares: " + Bucles_1.sumaCifrasPosPares(num));
		System.out.println(" - sumaAnillosCifra: " + Bucles_1.sumaAnillosCifra(num));
		System.out.println(" - multiplicaCifras: " + Bucles_1.multiplicaCifras(num));
		
		ResultadoBusqueda resBus = Bucles_1.digitoPar(num);
		System.out.println(" - " + resBus);
		
		System.out.println(" - todosDigitosPares: " + Bucles_1.todosDigitosPares(num));
		System.out.println(" - digitoMayor: " + Bucles_1.digitoMayorWhile(num));
		System.out.println(" - digitoMayorFor: " + Bucles_1.digitoMayorFor(num));
		System.out.println(" - digitoMenorFor: " + Bucles_1.digitoMenorFor(num));
		System.out.println(" - digitoMayor_Veces:" + Bucles_1.digitoMayor_Veces(num));
		System.out.println(" - digitoMenor_Veces:" + Bucles_1.digitoMenor_Veces(num));
		
	}
}
