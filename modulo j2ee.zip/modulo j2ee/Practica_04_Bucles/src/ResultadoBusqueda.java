
public class ResultadoBusqueda {

	boolean encontrado;
	int posicion;
	int elemento;
	/**
	 * @param encontrado
	 * @param posicion
	 * @param elemento
	 */
	public ResultadoBusqueda(boolean encontrado, int posicion, int elemento) {
		super();
		this.encontrado = encontrado;
		this.posicion = posicion;
		this.elemento = elemento;
	}
	public boolean isEncontrado() {
		return encontrado;
	}
	public void setEncontrado(boolean encontrado) {
		this.encontrado = encontrado;
	}
	public int getPosicion() {
		return posicion;
	}
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	public int getElemento() {
		return elemento;
	}
	public void setElemento(int elemento) {
		this.elemento = elemento;
	}
	
	@Override
	public String toString() {
		return "ResultadoBusqueda [encontrado=" + encontrado + ", posicion=" + posicion + ", elemento=" + elemento
				+ "]";
	}
	
	
}
