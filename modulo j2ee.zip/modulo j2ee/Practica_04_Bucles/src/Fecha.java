
public class Fecha {

	private int dia;
	private int mes;
	private int anio;
	
	public Fecha() {
		dia = 0;
		mes = 0;
		anio = 0;
	}
	
	public Fecha(int unDia, int unMes, int unAnio){
		dia = unDia;
		mes = unMes;
		anio = unAnio;
	}
	
	public void setDia(int unDia){
		dia = unDia;
	}
	
	public void setMes(int unMes){
		mes = unMes;
	}
	
	public void setAnio(int unAnio){
		anio = unAnio;
	}

	public int getDia(){
		return dia;
	}
	
	public int getMes(){
		return mes;
	}
	
	public int getAnio(){
		return anio;
	}
	
	public String aTexto() {
		return dia + "/" + mes + "/" + anio ;
	}


}


