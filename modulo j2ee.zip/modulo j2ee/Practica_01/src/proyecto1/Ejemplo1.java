package proyecto1;

public class Ejemplo1 {

	public static void main(String[] args) {

		//declaraci�n de variables
		System.out.println("Hola Mundo");
		
		String nombre = "Juanma";
		
		System.out.println(nombre);
		
		int edad = 49;
		
		System.out.println(edad);
		
		double altura = 1.67;
		
		System.out.println(altura);
		
		boolean vivo = true;
		
		System.out.println(vivo);
		
		//expresiones
		
		edad = 48 + 1;
		
		System.out.println(edad);
		
	
		int x = 1;
		int y = 2;
		int z = 4;
		
		int suma = x + y;
		
		System.out.println(suma);
		
		int resta = z - x;
			
		System.out.println(resta);
		
		int multiplicar = 2 * 4;
		
		System.out.println(multiplicar);
		
		int dividir = 4 /2;
		
		System.out.println(dividir);
				
		double Pi = Math.PI;
		
		double pi = 3.14;
		double radio = 10.2;
		double circunferencia = 2 * Pi * radio;
		
		System.out.println(Pi);
		System.out.println(circunferencia);
		
		int entero = 999999999;
		
		long largo = 999999999;
		
		
		

	}

}
