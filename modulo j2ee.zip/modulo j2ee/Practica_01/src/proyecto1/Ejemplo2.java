package proyecto1;

import java.lang.Math;

public class Ejemplo2 {

	final static int abogado = 12;
	
	public static void main(String[] args) {
		
		//Constantes
		final double 	G 			= 9.8;
		final int 		a�oActual 	= 2019;
		final double 	PI 			= 3.141593;
		final boolean 	cierto 		= true;
		final boolean 	falso 		= false;
				
		System.out.println("- Constantes");
		System.out.println(G);
		System.out.println(a�oActual);
		System.out.println(PI);
		System.out.println(cierto);
		System.out.println(falso);
		
		//Variables
		int 	resto 			= 2 % 6;
		int 	valorAbsoluto 	= Math.abs(-6);
		double 	elevado			= Math.pow (7,2); //elevado
		int valor_a = 'a';
		int valor_A = 'A';
		
		System.out.println("- Variables");
		System.out.println(resto);
		System.out.println(valorAbsoluto);
		System.out.println(elevado);
		System.out.println(valor_a);
		System.out.println(valor_A);
		
		//Expresiones
		double 	exp1 = Math.pow(7,-2);
		double 	exp2 = (double)(7 / 7) ;
		int 	exp3 = (int)PI;
		boolean exp4 = false && cierto;
		boolean exp5 = false == cierto;
		
		//System.out.println(5/0); -> produce error
		
		System.out.println("- Expresiones");
		System.out.println(exp1);
		System.out.println(exp2);
		System.out.println(exp3);
		System.out.println(exp4);
		System.out.println(exp5);
		
		//casting -> forzamos a que una variable de un tipo sea de otro
		int casting = (int)9.4;

		System.out.println("- Casting");
		System.out.println(casting);
		
		
		System.out.println("- Variable externa al m�todo");
		System.out.println("abogado - " + abogado);
		
		
		
	}
}


