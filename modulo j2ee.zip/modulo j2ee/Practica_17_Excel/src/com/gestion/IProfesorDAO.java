package com.gestion;
import java.util.List;

import com.model.Profesor;

public interface IProfesorDAO {
	public boolean registrar(Profesor cliente);
	public List<Profesor> obtener();
	public Profesor obtenerPorID(int id);
	public boolean actualizar(Profesor prof);
	public boolean eliminar(int id);
	public void listarResultados(List<Profesor> ListProf);
}
