package com.excel;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import com.gestion.ControllerProfesor;
import com.model.Profesor;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class ExcelWrite {

    private static final String EXCEL_FILE_LOCATION = "C:\\temp\\MyFirstExcel.xls";

    public static void main(String[] args) {

        //1. Create an Excel file
        WritableWorkbook myFirstWbook = null;
        try {

            myFirstWbook = Workbook.createWorkbook(new File(EXCEL_FILE_LOCATION));
            WritableSheet excelSheet = myFirstWbook.createSheet("Profesores", 0);

            WritableCellFormat cFormat = new WritableCellFormat();
            WritableFont font = new WritableFont(WritableFont.ARIAL, 14, WritableFont.BOLD);
            cFormat.setFont(font);
            
            // Cabecera
            Label label = new Label(0, 0, "Listado Profesores", cFormat);
            excelSheet.addCell(label);

            label = new Label(0, 1, "Nombre",cFormat);
            excelSheet.addCell(label);

            label = new Label(1, 1, "Apellidos",cFormat);
            excelSheet.addCell(label);

            label = new Label(2, 1, "DNI",cFormat);
            excelSheet.addCell(label);

            label = new Label(3, 1, "Estado civil", cFormat);
            excelSheet.addCell(label);

            label = new Label(4, 1, "Departamento", cFormat);
            excelSheet.addCell(label);

            label = new Label(5, 1, "N� Despacho", cFormat);
            excelSheet.addCell(label);

            label = new Label(6, 1, "Fecha ingreso", cFormat);
            excelSheet.addCell(label);
            
            ControllerProfesor controllerProf = new ControllerProfesor();
            List<Profesor> ListProf = controllerProf.obtener();
            
            //listado datos
            int i = 2;
            Iterator<Profesor> iter = ListProf.iterator();
    		while (iter.hasNext()) {
    			
    			Profesor prof = (Profesor)iter.next();
    			System.out.println(prof);
    			
    			label = new Label(0, i, prof.getNombre());
                excelSheet.addCell(label);
                
    			label = new Label(1, i, prof.getApellido1() + " " + prof.getApellido2());
                excelSheet.addCell(label);

                label = new Label(2, i, prof.getDni());
                excelSheet.addCell(label);
                
                label = new Label(3, i, prof.getEstadoCivil());
                excelSheet.addCell(label);
                
                label = new Label(4, i, prof.getNombreDep());
                excelSheet.addCell(label);
                
                label = new Label(5, i, prof.getNumDespacho());
                excelSheet.addCell(label);
    			
                label = new Label(6, i, prof.getA�oIncorporacion());
                excelSheet.addCell(label);
                
                i++;
    		}

            myFirstWbook.write();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (WriteException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            if (myFirstWbook != null) {
                try {
                    myFirstWbook.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (WriteException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
