
public class MainAgenda {

	public static void main(String[] args) {

		Contacto contacto1 = new Contacto(
			"Luis Pereda",
			new Telefono("+34", 395365365, "movil"),
			new Email("Luis_54@Gmail.com"),
			new Direccion("Calle", "Alberto Figueroa", "32", "2D", "28020", "Madrid", "Madrid")
		);
		
		Contacto contacto2 = new Contacto(
				"Maria Perez",
				new Telefono("+34", 6565665, "Casa"),
				new Email("Mar�a4@hotmail.com"),
				new Direccion("Calle", "Alberto Figueroa", "32", "2D", "28020", "Madrid", "Madrid")
			);
		
		System.out.println(contacto1.aTexto());
		
		System.out.println(LibAgenda.getNombreEmail(contacto1.getCorreo().aTexto()));
		System.out.println(LibAgenda.getDominioEmail(contacto1.getCorreo().aTexto()));
		System.out.println(LibAgenda.getExtensionEmail(contacto1.getCorreo().aTexto()));
		
		System.out.println(contacto1.getCorreo().getDominioEmail());
		
//		//Contacto[] agenda = new Contacto[];
//		Contacto agenda[] = new Contacto[10];
//		
//		agenda[0] = contacto1;
//		agenda[1] = contacto2;
//		
//		for(int i=0; i<agenda.length; i++) {
//			System.out.println(agenda[i].aTexto());
//		}
		
				
	}
}


