
public class Contacto {
	
	private String nombre;
	private Telefono telefono;
	private Email correo;
	private Direccion direccion;
	
	/**
	 * @param nombre
	 * @param telefono
	 * @param correo
	 * @param direccion
	 */
	public Contacto(String nombre, Telefono telefono, Email correo, Direccion direccion) {
		this.nombre = nombre;
		this.telefono = telefono;
		this.correo = correo;
		this.direccion = direccion;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Telefono getTelefono() {
		return telefono;
	}
	
	public void setTelefono(Telefono telefono) {
		this.telefono = telefono;
	}
	
	public Email getCorreo() {
		return correo;
	}
	
	public void setCorreo(Email correo) {
		this.correo = correo;
	}
	
	public Direccion getDireccion() {
		return direccion;
	}
	
	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}
	
	public String aTexto() {
		return "nombre=" + nombre + ", telefono=" + telefono.aTexto() + ", correo=" + correo.aTexto() + ", direccion=["
				+ direccion.aTexto() + "]";
	}
}
