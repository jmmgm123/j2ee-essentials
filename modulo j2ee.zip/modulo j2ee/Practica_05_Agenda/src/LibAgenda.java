
public class LibAgenda {

	public static String getNombreEmail(String email) {
		return email.substring(0, email.indexOf("@"));
	}
	
	public static String getDominioEmail(String email) {
		return email.substring(email.indexOf("@")+1, email.indexOf("."));
	}
	
	public static String getExtensionEmail(String email) {
		return email.substring(email.indexOf(".")+ 1, email.length());
	}

}
