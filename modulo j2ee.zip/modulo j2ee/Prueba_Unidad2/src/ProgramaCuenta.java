import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProgramaCuenta {
	
	public static int cuentasNegativas(List<CuentaBancaria> listCuentasBancarias) {
		
		int negativo = 0;
		Iterator<CuentaBancaria> iter = listCuentasBancarias.iterator();
		while (iter.hasNext()) {
			CuentaBancaria cuenta = (CuentaBancaria)iter.next();
			int saldo = cuenta.getSaldo();
			if(saldo<0) {
				negativo++;
			}
		}
		return negativo;
	}
	
	public static boolean todasPositivas(List<CuentaBancaria> listCuentasBancarias) {
		
		boolean positivos = true;
	
		Iterator<CuentaBancaria> iter = listCuentasBancarias.iterator();
		while (iter.hasNext() && positivos) {
			CuentaBancaria cuenta = (CuentaBancaria)iter.next();
			int saldo = cuenta.getSaldo();
			if(saldo<0) {
				positivos = false;
			}
		}
		return positivos;
	}
	
	public static void mostrarListadoClientes(List<CuentaBancaria> listCuentasBancarias) {
		Iterator<CuentaBancaria> iter = listCuentasBancarias.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
	
	
	public static void main(String[] args) {
		// Dada una coleccion de cuentas bancarias calcular:
		// - cuantas en rojo
		// - Todo positivo
		
		
		CuentaBancaria cb1 = new CuentaBancaria("Juan", "Pe�a Sierra", "00840010021502155412", "32154874P", -500);
		CuentaBancaria cb2 = new CuentaBancaria("cl1Mar�a", "Saenz G�mez", "001505486215587851259", "11112254H", -200);
		CuentaBancaria cb3 = new CuentaBancaria("Eva", "Saenz G�mez", "00215497512364975125", "33225588O", 1000);
		CuentaBancaria cb4 = new CuentaBancaria("Evaristo", "Lopez Lis", "00233334445556667778", "21548745D", 1000);
		
		List<CuentaBancaria> cuentasBancarias = new ArrayList<CuentaBancaria>();
		cuentasBancarias.add(cb1);
		cuentasBancarias.add(cb2);
		cuentasBancarias.add(cb3);
		cuentasBancarias.add(cb4);
		
		mostrarListadoClientes(cuentasBancarias);
		System.out.println("Cuentas bancarias con saldo negativo: " + cuentasNegativas(cuentasBancarias));
		System.out.println("�Todos las cuentas bancarias con saldo positivo? " + todasPositivas(cuentasBancarias));
		
	}

}


